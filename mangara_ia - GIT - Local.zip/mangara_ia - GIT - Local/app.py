from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import os
import requests
from dotenv import load_dotenv

# Carrega variáveis locais
load_dotenv()

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)

# Configurações da OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

SYS_PROMPT = (
    "Você é a Mangará IA, uma consultora especializada em herbologia e agroecologia. "
    "Ajude o usuário a escolher plantas, flores, frutas ou ervas adequadas conforme o contexto. "
    "Responda sempre em português do Brasil, de forma curta, clara e objetiva. "
    "Evite respostas longas; use listas, tabelas e frases resumidas."
)

# Rotas
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/herbario")
def herbario():
    return render_template("herbario.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/login-adm")
def login_adm():
    return render_template("login-adm.html")

@app.route("/paineladm")
def painel_adm():
    return render_template("paineladm.html")

# API do chatbot
@app.post("/api/ai")
def api_ai():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("prompt") or "").strip()
    if not prompt:
        return jsonify({"error": "prompt vazio"}), 400

    try:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": OPENAI_MODEL,
                "messages": [
                    {"role": "system", "content": SYS_PROMPT},
                    {"role": "user", "content": prompt}
                ]
            },
            timeout=30
        )
        j = r.json()
        if r.status_code >= 400:
            return jsonify({"error": f"OpenAI {r.status_code}: {j}"}), 500

        text = (j.get("choices") or [{}])[0].get("message", {}).get("content", "Sem resposta.")
        return jsonify({"answer": text})

    except Exception as e:
        return jsonify({"error": f"Falha ao consultar IA: {e}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
