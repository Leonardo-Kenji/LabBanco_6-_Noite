<?php
/**
 * API UNIFICADA - Plantas e Categorias
 * Mangaratá - Núcleo Agroecológico
 * 
 * Endpoints:
 * - get_plantas.php?action=plantas (default)
 * - get_plantas.php?action=categorias
 * - get_plantas.php?action=todas (plantas + categorias)
 */

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

try {
    // Determinar ação
    $action = isset($_GET['action']) ? strtolower($_GET['action']) : 'plantas';
    
    switch ($action) {
        case 'categorias':
            getCategorias();
            break;
            
        case 'todas':
            getTodasDados();
            break;
            
        case 'plantas':
        default:
            getPlantas();
            break;
    }
    
} catch (Exception $e) {
    error_log("Erro em get_plantas.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao processar requisição',
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

// ===================================================
// FUNÇÃO: Buscar Plantas
// ===================================================
function getPlantas() {
    global $conexao;
    
    // Parâmetros de filtro
    $tipo = isset($_GET['tipo']) ? intval($_GET['tipo']) : null;
    $utilidade = isset($_GET['utilidade']) ? intval($_GET['utilidade']) : null;
    $busca = isset($_GET['busca']) ? trim($_GET['busca']) : null;
    $id = isset($_GET['id']) ? intval($_GET['id']) : null;
    
    // Query base
    $sql = "SELECT 
                p.ID,
                p.NOMECIE as NOME_CIENTIFICO,
                p.NOMEPOP as NOME_POPULAR,
                p.TAM as TAMANHO,
                p.SOL as HORAS_SOL,
                u.CAT as UTILIDADE,
                t.CAT as TIPO,
                s.CAT as SOLO,
                c.CAT as CLIMA,
                p.UTI_ID,
                p.TIPO_ID,
                p.SOLO_ID,
                p.CLIMA_ID
            FROM MANGA.PLANTA p
            LEFT JOIN MANGA.UTILIDADE u ON p.UTI_ID = u.ID
            LEFT JOIN MANGA.TIPO t ON p.TIPO_ID = t.ID
            LEFT JOIN MANGA.SOLO s ON p.SOLO_ID = s.ID
            LEFT JOIN MANGA.CLIMA c ON p.CLIMA_ID = c.ID
            WHERE 1=1";
    
    $params = [];
    $types = "";
    
    // Buscar por ID específico
    if ($id) {
        $sql .= " AND p.ID = ?";
        $params[] = $id;
        $types .= "i";
    }
    
    // Filtrar por tipo
    if ($tipo) {
        $sql .= " AND p.TIPO_ID = ?";
        $params[] = $tipo;
        $types .= "i";
    }
    
    // Filtrar por utilidade
    if ($utilidade) {
        $sql .= " AND p.UTI_ID = ?";
        $params[] = $utilidade;
        $types .= "i";
    }
    
    // Filtrar por busca (nome científico ou popular)
    if ($busca) {
        $sql .= " AND (p.NOMECIE LIKE ? OR p.NOMEPOP LIKE ?)";
        $buscaParam = "%{$busca}%";
        $params[] = $buscaParam;
        $params[] = $buscaParam;
        $types .= "ss";
    }
    
    $sql .= " ORDER BY p.NOMECIE";
    
    // Preparar e executar
    $stmt = $conexao->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Erro ao preparar consulta: " . $conexao->error);
    }
    
    // Bind parameters se existirem
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    $plantas = [];
    while ($row = $resultado->fetch_assoc()) {
        $plantas[] = [
            'id' => $row['ID'],
            'nomeCientifico' => $row['NOME_CIENTIFICO'],
            'nomePopular' => $row['NOME_POPULAR'],
            'tamanho' => floatval($row['TAMANHO']),
            'horasSol' => floatval($row['HORAS_SOL']),
            'utilidade' => $row['UTILIDADE'],
            'tipo' => $row['TIPO'],
            'solo' => $row['SOLO'],
            'clima' => $row['CLIMA'],
            'utiId' => $row['UTI_ID'],
            'tipoId' => $row['TIPO_ID'],
            'soloId' => $row['SOLO_ID'],
            'climaId' => $row['CLIMA_ID']
        ];
    }
    
    $stmt->close();
    
    // Se buscar por ID, retornar apenas uma planta
    if ($id) {
        echo json_encode([
            'success' => true,
            'planta' => count($plantas) > 0 ? $plantas[0] : null
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'success' => true,
            'total' => count($plantas),
            'plantas' => $plantas
        ], JSON_UNESCAPED_UNICODE);
    }
}

// ===================================================
// FUNÇÃO: Buscar Categorias
// ===================================================
function getCategorias() {
    global $conexao;
    
    $categoria = isset($_GET['categoria']) ? strtolower($_GET['categoria']) : 'todas';
    
    try {
        switch ($categoria) {
            case 'tipos':
                $result = buscarCategoria('TIPO');
                echo json_encode([
                    'success' => true,
                    'categoria' => 'tipos',
                    'dados' => $result
                ], JSON_UNESCAPED_UNICODE);
                break;
                
            case 'utilidades':
                $result = buscarCategoria('UTILIDADE');
                echo json_encode([
                    'success' => true,
                    'categoria' => 'utilidades',
                    'dados' => $result
                ], JSON_UNESCAPED_UNICODE);
                break;
                
            case 'solos':
                $result = buscarCategoria('SOLO');
                echo json_encode([
                    'success' => true,
                    'categoria' => 'solos',
                    'dados' => $result
                ], JSON_UNESCAPED_UNICODE);
                break;
                
            case 'climas':
                $result = buscarCategoria('CLIMA');
                echo json_encode([
                    'success' => true,
                    'categoria' => 'climas',
                    'dados' => $result
                ], JSON_UNESCAPED_UNICODE);
                break;
                
            case 'todas':
            default:
                echo json_encode([
                    'success' => true,
                    'categorias' => [
                        'tipos' => buscarCategoria('TIPO'),
                        'utilidades' => buscarCategoria('UTILIDADE'),
                        'solos' => buscarCategoria('SOLO'),
                        'climas' => buscarCategoria('CLIMA')
                    ]
                ], JSON_UNESCAPED_UNICODE);
                break;
        }
    } catch (Exception $e) {
        throw new Exception("Erro ao buscar categorias: " . $e->getMessage());
    }
}

// ===================================================
// FUNÇÃO: Buscar uma categoria específica
// ===================================================
function buscarCategoria($tabela) {
    global $conexao;
    
    $stmt = $conexao->query("SELECT ID, CAT as NOME FROM MANGA.$tabela ORDER BY CAT");
    
    if (!$stmt) {
        throw new Exception("Erro ao buscar $tabela: " . $conexao->error);
    }
    
    return $stmt->fetch_all(MYSQLI_ASSOC);
}

// ===================================================
// FUNÇÃO: Buscar tudo de uma vez
// ===================================================
function getTodasDados() {
    global $conexao;
    
    // Buscar plantas
    $sqlPlantas = "SELECT 
                        p.ID,
                        p.NOMECIE as NOME_CIENTIFICO,
                        p.NOMEPOP as NOME_POPULAR,
                        p.TAM as TAMANHO,
                        p.SOL as HORAS_SOL,
                        u.CAT as UTILIDADE,
                        t.CAT as TIPO,
                        s.CAT as SOLO,
                        c.CAT as CLIMA,
                        p.UTI_ID,
                        p.TIPO_ID
                    FROM MANGA.PLANTA p
                    LEFT JOIN MANGA.UTILIDADE u ON p.UTI_ID = u.ID
                    LEFT JOIN MANGA.TIPO t ON p.TIPO_ID = t.ID
                    LEFT JOIN MANGA.SOLO s ON p.SOLO_ID = s.ID
                    LEFT JOIN MANGA.CLIMA c ON p.CLIMA_ID = c.ID
                    ORDER BY p.NOMECIE";
    
    $resultado = $conexao->query($sqlPlantas);
    $plantas = [];
    
    if ($resultado) {
        while ($row = $resultado->fetch_assoc()) {
            $plantas[] = [
                'id' => $row['ID'],
                'nomeCientifico' => $row['NOME_CIENTIFICO'],
                'nomePopular' => $row['NOME_POPULAR'],
                'tamanho' => floatval($row['TAMANHO']),
                'horasSol' => floatval($row['HORAS_SOL']),
                'utilidade' => $row['UTILIDADE'],
                'tipo' => $row['TIPO'],
                'solo' => $row['SOLO'],
                'clima' => $row['CLIMA'],
                'utiId' => $row['UTI_ID'],
                'tipoId' => $row['TIPO_ID']
            ];
        }
    }
    
    // Buscar categorias
    echo json_encode([
        'success' => true,
        'total' => count($plantas),
        'plantas' => $plantas,
        'categorias' => [
            'tipos' => buscarCategoria('TIPO'),
            'utilidades' => buscarCategoria('UTILIDADE'),
            'solos' => buscarCategoria('SOLO'),
            'climas' => buscarCategoria('CLIMA')
        ]
    ], JSON_UNESCAPED_UNICODE);
}
?>