// ========== NAVEGAÇÃO MOBILE ==========
function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.classList.toggle('active');
}

document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll('nav a');
    links.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                const menu = document.getElementById('menu');
                if (menu) {
                    menu.classList.remove('active');
                }
            }
        });
    });
});

// ========== MARCAR LINK ATIVO ==========
function setActiveLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const links = document.querySelectorAll('nav a');
    
    links.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        
        if (href === currentPage || 
            (currentPage === '' && href === 'index.html')) {
            link.classList.add('active');
        }
    });
}

window.addEventListener('DOMContentLoaded', setActiveLink);

// ========== CHATBOT IA ==========
function abrirChatbot() {
    alert('Chatbot em desenvolvimento!\n\nEm breve você poderá conversar com nosso assistente virtual sobre plantas e agroecologia.');
}

// ========== FUNÇÕES AUXILIARES ==========
function mostrarMensagem(tipo, texto) {
    const mensagem = document.createElement('div');
    mensagem.className = tipo === 'success' ? 'success-message' : 'error-message';
    mensagem.textContent = texto;
    mensagem.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(mensagem);
    
    setTimeout(() => {
        mensagem.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => mensagem.remove(), 300);
    }, 3000);
}

function formatarData(dataISO) {
    if (!dataISO) return '';
    const data = new Date(dataISO + 'T00:00:00');
    return data.toLocaleDateString('pt-BR', { 
        day: '2-digit', 
        month: 'short', 
        year: 'numeric' 
    });
}

// ========== TOGGLE PASSWORD (MOSTRAR/OCULTAR SENHA) ==========
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    if (input.type === 'password') {
        input.type = 'text';
        button.classList.add('visible');
        button.setAttribute('aria-label', 'Ocultar senha');
    } else {
        input.type = 'password';
        button.classList.remove('visible');
        button.setAttribute('aria-label', 'Mostrar senha');
    }
}

// ========== POPULAR SELETOR DE DATA (DIA/MÊS/ANO) ==========
document.addEventListener('DOMContentLoaded', () => {
    const diaSelect = document.getElementById('dia');
    const anoSelect = document.getElementById('ano');
    
    if (diaSelect && anoSelect) {
        // Popular dias (1-31)
        for (let i = 1; i <= 31; i++) {
            const option = document.createElement('option');
            option.value = i.toString().padStart(2, '0');
            option.textContent = i;
            diaSelect.appendChild(option);
        }
        
        // Popular anos (1920 até ano atual)
        const anoAtual = new Date().getFullYear();
        for (let i = anoAtual; i >= 1920; i--) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            anoSelect.appendChild(option);
        }
        
        // Atualizar campo hidden quando selecionar data
        const mesSelect = document.getElementById('mes');
        const dataNascimentoHidden = document.getElementById('dataNascimento');
        
        function atualizarDataHidden() {
            const dia = diaSelect.value;
            const mes = mesSelect.value;
            const ano = anoSelect.value;
            
            if (dia && mes && ano) {
                dataNascimentoHidden.value = `${ano}-${mes}-${dia}`;
            }
        }
        
        diaSelect.addEventListener('change', atualizarDataHidden);
        mesSelect.addEventListener('change', atualizarDataHidden);
        anoSelect.addEventListener('change', atualizarDataHidden);
    }
});

// ========== LOGIN USUÁRIO ==========
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const senha = document.getElementById('senha').value;
            
            // Capturar URL de redirecionamento
            const urlParams = new URLSearchParams(window.location.search);
            const redirectUrl = urlParams.get('redirect') || '';
            
            const btnSubmit = loginForm.querySelector('button[type="submit"]');
            btnSubmit.disabled = true;
            btnSubmit.textContent = 'Entrando...';
            
            try {
                const response = await fetch('processa_login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `tipo=usuario&email=${encodeURIComponent(email)}&senha=${encodeURIComponent(senha)}&redirect=${encodeURIComponent(redirectUrl)}`
                });
                
                const resultado = await response.json();
                
                if (resultado.sucesso) {
                    // Salvar dados no localStorage
                    salvarDadosUsuario({
                        nome: resultado.nome,
                        email: resultado.email,
                        tipo: resultado.tipoUsuario,
                        isAdmin: resultado.tipoUsuario == 1
                    });
                    
                    mostrarMensagem('success', 'Login realizado com sucesso!');
                    setTimeout(() => {
                        window.location.href = resultado.redirect;
                    }, 1000);
                } else {
                    mostrarMensagem('error', resultado.mensagem || 'Erro no login');
                    btnSubmit.disabled = false;
                    btnSubmit.textContent = 'Entrar';
                }
            } catch (erro) {
                console.error('Erro:', erro);
                mostrarMensagem('error', 'Erro ao conectar com o servidor!');
                btnSubmit.disabled = false;
                btnSubmit.textContent = 'Entrar';
            }
        });
    }
});

// ========== LOGIN ADMINISTRADOR ==========
document.addEventListener('DOMContentLoaded', () => {
    const loginAdmForm = document.getElementById('loginAdmForm');
    
    if (loginAdmForm) {
        loginAdmForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('emailAdm').value;
            const senha = document.getElementById('senhaAdm').value;
            
            const btnSubmit = loginAdmForm.querySelector('button[type="submit"]');
            btnSubmit.disabled = true;
            btnSubmit.textContent = 'Entrando...';
            
            try {
                const response = await fetch('processa_login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `tipo=admin&email=${encodeURIComponent(email)}&senha=${encodeURIComponent(senha)}`
                });
                
                const resultado = await response.json();
                
                if (resultado.sucesso) {
                    mostrarMensagem('success', 'Login de administrador realizado!');
                    setTimeout(() => {
                        window.location.href = 'paineladm.php';
                    }, 1500);
                } else {
                    const errorMessage = document.getElementById('errorMessage');
                    if (errorMessage) {
                        errorMessage.textContent = resultado.mensagem || 'Credenciais inválidas';
                        errorMessage.style.display = 'block';
                        setTimeout(() => {
                            errorMessage.style.display = 'none';
                        }, 3000);
                    }
                    btnSubmit.disabled = false;
                    btnSubmit.textContent = 'Entrar como Admin';
                }
            } catch (erro) {
                console.error('Erro:', erro);
                mostrarMensagem('error', 'Erro ao conectar com o servidor!');
                btnSubmit.disabled = false;
                btnSubmit.textContent = 'Entrar como Admin';
            }
        });
    }
});

// ========== FORMULÁRIO DE CADASTRO ==========
document.addEventListener('DOMContentLoaded', () => {
    const cadastroForm = document.getElementById('cadastroForm');
    
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const nome = document.getElementById('nome').value.trim();
            const email = document.getElementById('emailCadastro').value.trim();
            const dataNascimento = document.getElementById('dataNascimento').value;
            const senha = document.getElementById('senhaCadastro').value;
            const confirmaSenha = document.getElementById('confirmaSenha').value;
            
            const mensagemErro = document.getElementById('mensagemErro');
            const mensagemSucesso = document.getElementById('mensagemSucesso');
            
            // Limpar mensagens
            mensagemErro.style.display = 'none';
            mensagemSucesso.style.display = 'none';
            
            // Validar data de nascimento
            if (!dataNascimento) {
                mensagemErro.textContent = 'Selecione sua data de nascimento!';
                mensagemErro.style.display = 'block';
                return;
            }
            
            // Validações básicas no frontend
            if (senha.length < 6) {
                mensagemErro.textContent = 'A senha deve ter pelo menos 6 caracteres!';
                mensagemErro.style.display = 'block';
                return;
            }
            
            if (senha !== confirmaSenha) {
                mensagemErro.textContent = 'As senhas não conferem!';
                mensagemErro.style.display = 'block';
                return;
            }
            
            const btnSubmit = cadastroForm.querySelector('button[type="submit"]');
            btnSubmit.disabled = true;
            btnSubmit.textContent = 'Criando conta...';
            
            try {
                const response = await fetch('processa_cadastro.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `nome=${encodeURIComponent(nome)}&email=${encodeURIComponent(email)}&data_nascimento=${encodeURIComponent(dataNascimento)}&senha=${encodeURIComponent(senha)}&confirma_senha=${encodeURIComponent(confirmaSenha)}`
                });
                
                const resultado = await response.json();
                
                if (resultado.sucesso) {
                    mensagemSucesso.textContent = resultado.mensagem;
                    mensagemSucesso.style.display = 'block';
                    cadastroForm.reset();
                    
                    setTimeout(() => {
                        window.location.href = resultado.redirect;
                    }, 2000);
                } else {
                    mensagemErro.textContent = resultado.mensagem || 'Erro ao criar a conta';
                    mensagemErro.style.display = 'block';
                    btnSubmit.disabled = false;
                    btnSubmit.textContent = 'Criar Conta';
                }
            } catch (erro) {
                console.error('Erro:', erro);
                mensagemErro.textContent = 'Erro ao conectar com o servidor!';
                mensagemErro.style.display = 'block';
                btnSubmit.disabled = false;
                btnSubmit.textContent = 'Criar Conta';
            }
        });
    }
});

// ========== FUNÇÕES DE GERENCIAMENTO DE SESSÃO ==========

/**
 * Salvar dados do usuário no localStorage
 */
function salvarDadosUsuario(usuario) {
    try {
        localStorage.setItem('usuario_logado', JSON.stringify({
            nome: usuario.nome,
            email: usuario.email,
            tipo: usuario.tipo,
            isAdmin: usuario.isAdmin
        }));
        console.log('✅ Dados do usuário salvos no cache');
    } catch (erro) {
        console.error('Erro ao salvar dados do usuário:', erro);
    }
}

/**
 * Limpar dados do usuário do localStorage
 */
function limparDadosUsuario() {
    try {
        localStorage.removeItem('usuario_logado');
        console.log('✅ Dados do usuário removidos do cache');
    } catch (erro) {
        console.error('Erro ao limpar dados do usuário:', erro);
    }
}

/**
 * Atualizar menu usando dados do cache (localStorage)
 */
function atualizarMenuPeloCache() {
    try {
        const usuarioCache = localStorage.getItem('usuario_logado');
        
        if (usuarioCache) {
            const usuario = JSON.parse(usuarioCache);
            mostrarMenuLogado(usuario);
            console.log('✅ Menu atualizado pelo cache');
            return true;
        } else {
            mostrarMenuNaoLogado();
            return false;
        }
    } catch (erro) {
        console.error('Erro ao atualizar menu pelo cache:', erro);
        mostrarMenuNaoLogado();
        return false;
    }
}

/**
 * Mostrar menu para usuário logado
 */
function mostrarMenuLogado(dados) {
    const menuElement = document.getElementById('menu');
    if (!menuElement) return;
    
    // Remover link de login se existir
    const loginLink = menuElement.querySelector('a[href="login.html"]');
    if (loginLink && loginLink.parentElement) {
        loginLink.parentElement.remove();
    }
    
    // Verificar se já existe status de usuário
    let userStatus = document.getElementById('userStatus');
    
    if (!userStatus) {
        userStatus = document.createElement('li');
        userStatus.id = 'userStatus';
        menuElement.appendChild(userStatus);
    }
    
    // Badge de admin/autor
    let badge = '';
    if (dados.isAdmin) {
        badge = '<span class="admin-badge-small">Admin</span>';
    } else if (dados.isAutor || dados.tipo == 2) {
        badge = '<span class="autor-badge-small">Autor</span>';
    }
    
    userStatus.innerHTML = `
        <div class="user-menu">
            <span class="user-info">
                <strong>${dados.nome}</strong> ${badge}
            </span>
            <button class="btn-logout-small" onclick="logout()" title="Sair">
                Sair
            </button>
        </div>
    `;
    
    // Mostrar/esconder links do painel admin
    const adminLink = document.getElementById('adminLink');
    if (adminLink) {
        if (dados.isAdmin) {
            adminLink.style.display = 'block';
        } else {
            adminLink.style.display = 'none';
        }
    }
    
    // Mostrar/esconder link do painel autor
    const autorLink = document.getElementById('autorLink');
    if (autorLink) {
        if (dados.isAutor || dados.tipo == 2 || dados.isAdmin) {
            autorLink.style.display = 'block';
        } else {
            autorLink.style.display = 'none';
        }
    }
}

/**
 * Mostrar menu para usuário não logado
 */
function mostrarMenuNaoLogado() {
    const menuElement = document.getElementById('menu');
    if (!menuElement) return;
    
    // Remover status de usuário se existir
    const userStatus = document.getElementById('userStatus');
    if (userStatus) {
        userStatus.remove();
    }
    
    // Adicionar link de login se não existir
    const loginLink = menuElement.querySelector('a[href="login.html"]');
    if (!loginLink) {
        const li = document.createElement('li');
        li.innerHTML = '<a href="login.html">Login</a>';
        menuElement.appendChild(li);
    }
    
    // Esconder link do painel admin
    const adminLink = document.getElementById('adminLink');
    if (adminLink) {
        adminLink.style.display = 'none';
    }
}

/**
 * Atualizar menu com base na sessão do servidor
 */
async function atualizarMenuPelaSessao() {
    try {
        const response = await fetch('verifica_sessao.php');
        const dados = await response.json();
        
        console.log('📡 Resposta da sessão:', dados);
        
        if (dados.autenticado || dados.logado) {
            // Salvar no localStorage
            salvarDadosUsuario({
                nome: dados.nome,
                email: dados.email,
                tipo: dados.tipo_usuario || dados.tipo,
                isAdmin: dados.isAdmin
            });
            
            // Atualizar menu
            mostrarMenuLogado({
                nome: dados.nome,
                email: dados.email,
                tipo: dados.tipo_usuario || dados.tipo,
                isAdmin: dados.isAdmin
            });
        } else {
            // Limpar localStorage
            limparDadosUsuario();
            mostrarMenuNaoLogado();
        }
    } catch (erro) {
        console.log('⚠️ Erro ao verificar sessão:', erro);
        // Em caso de erro, tentar usar cache
        atualizarMenuPeloCache();
    }
}

// ========== LOGOUT ==========
function logout() {
    if (confirm('Tem certeza que deseja sair?')) {
        // Limpar cache local
        limparDadosUsuario();
        
        // Fazer logout no servidor
        fetch('processa_logout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(() => {
            window.location.href = 'index.html';
        })
        .catch(erro => {
            console.error('Erro ao fazer logout:', erro);
            // Mesmo com erro, redirecionar
            window.location.href = 'index.html';
        });
    }
}

// ========== PAINEL ADMIN - ABAS ==========
function showTab(tabName) {
    const allTabs = document.querySelectorAll('.tab-content');
    const allButtons = document.querySelectorAll('.tab-btn');
    
    allTabs.forEach(tab => tab.classList.remove('active'));
    allButtons.forEach(btn => btn.classList.remove('active'));
    
    const selectedTab = document.getElementById(tabName + '-tab');
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    if (event && event.target) {
        event.target.classList.add('active');
    }
    
    // Carregar dados específicos da aba
    if (tabName === 'noticias') {
        carregarNoticias();
    } else if (tabName === 'usuarios') {
        carregarUsuarios();
    }
}

// ========== EXECUTAR VERIFICAÇÃO DE AUTENTICAÇÃO ==========
document.addEventListener('DOMContentLoaded', () => {
    atualizarMenuPelaSessao();
});

// ========== SISTEMA DE INTERAÇÕES (CURTIDAS E COMENTÁRIOS) ==========

/**
 * Classe para gerenciar interações em artigos
 */
class InteracoesArtigo {
    constructor(artigoId) {
        this.artigoId = artigoId;
        this.curtido = false;
        this.totalCurtidas = 0;
        this.comentarios = [];
    }

    // ========== CURTIDAS ==========

    /**
     * Inicializar sistema de curtidas
     */
    async inicializarCurtidas(containerId = 'curtidas-container') {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Verificar se já curtiu e total de curtidas (só se estiver logado)
        if (this.usuarioLogado) {
            await this.verificarCurtida();
        } else {
            // Se não logado, buscar apenas o total de curtidas
            await this.buscarTotalCurtidas();
        }

        // Criar HTML do botão (sempre visível)
        container.innerHTML = `
            <div class="curtida-wrapper">
                <button class="btn-curtir ${this.curtido ? 'curtido' : ''}" id="btnCurtir">
                    <span class="icone-curtida">${this.curtido ? '❤️' : '🤍'}</span>
                    <span class="texto-curtida">${this.curtido ? 'Curtido' : 'Curtir'}</span>
                    <span class="contador-curtidas">${this.totalCurtidas}</span>
                </button>
                ${!this.usuarioLogado ? '<small style="display: block; margin-top: 0.5rem; color: #999; text-align: center;">💡 Faça login para curtir</small>' : ''}
            </div>
        `;

        // Adicionar event listener
        document.getElementById('btnCurtir').addEventListener('click', () => {
            if (!this.usuarioLogado) {
                // Redirecionar para login
                if (confirm('Você precisa fazer login para curtir este artigo.\n\nDeseja fazer login agora?')) {
                    window.location.href = this.redirectUrl;
                }
                return;
            }
            this.toggleCurtida();
        });
    }

    /**
     * Buscar total de curtidas (sem verificar se o usuário curtiu)
     */
    async buscarTotalCurtidas() {
        try {
            const response = await fetch(`processa_interacoes.php?acao=obter_curtidas&artigo_id=${this.artigoId}`);
            
            if (!response.ok) {
                console.error('Erro HTTP ao buscar curtidas:', response.status);
                this.totalCurtidas = 0;
                return;
            }
            
            const data = await response.json();
            this.totalCurtidas = data.total || 0;
        } catch (erro) {
            console.error('Erro ao buscar curtidas:', erro);
            this.totalCurtidas = 0;
        }
    }

    /**
     * Verificar se o usuário já curtiu o artigo
     */
    async verificarCurtida() {
        try {
            const response = await fetch(`processa_interacoes.php?acao=obter_curtidas&artigo_id=${this.artigoId}`);
            if (!response.ok) {
                console.error('Erro HTTP ao verificar curtida:', response.status);
                this.curtido = false;
                this.totalCurtidas = 0;
                return;
            }
            
            const data = await response.json();
            
            this.curtido = data.ja_curtiu || false;
            this.totalCurtidas = data.total || 0;
            
        } catch (erro) {
            console.error('Erro ao verificar curtida:', erro);
        }
    }

    /**
     * Curtir ou descurtir artigo
     */
    async toggleCurtida() {
        const btnCurtir = document.getElementById('btnCurtir');
        if (!btnCurtir) return;

        // Desabilitar botão temporariamente
        btnCurtir.disabled = true;

        try {
            const acao = this.curtido ? 'descurtir' : 'curtir';
            const response = await fetch('processa_interacoes.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `acao=${acao}&artigo_id=${this.artigoId}`
            });

            const resultado = await response.json();

            // Verificar se usuário não está autenticado
            if (response.status === 401 || resultado.redirect) {
                // Salvar URL atual para retornar após login
                const urlAtual = window.location.href;
                const loginUrl = resultado.redirect || 'login.html';
                
                // Mostrar mensagem antes de redirecionar
                this.mostrarFeedback('❌ Você precisa estar logado para curtir!', 'error');
                
                // Redirecionar após 1.5 segundos
                setTimeout(() => {
                    window.location.href = loginUrl + '?redirect=' + encodeURIComponent(urlAtual);
                }, 1500);
                return;
            }

            if (resultado.sucesso) {
                // Atualizar estado
                this.curtido = !this.curtido;
                this.totalCurtidas = resultado.total || this.totalCurtidas;

                // Atualizar visual
                this.atualizarBotaoCurtida();

                // Mostrar feedback
                this.mostrarFeedback(resultado.mensagem, 'success');

            } else {
                this.mostrarFeedback(resultado.mensagem || 'Erro ao processar curtida', 'error');
            }

        } catch (erro) {
            console.error('Erro ao curtir:', erro);
            this.mostrarFeedback('Erro ao processar curtida', 'error');
        } finally {
            btnCurtir.disabled = false;
        }
    }

    /**
     * Atualizar visual do botão de curtida
     */
    atualizarBotaoCurtida() {
        const btnCurtir = document.getElementById('btnCurtir');
        const icone = btnCurtir.querySelector('.icone-curtida');
        const texto = btnCurtir.querySelector('.texto-curtida');
        const contador = btnCurtir.querySelector('.contador-curtidas');

        if (this.curtido) {
            btnCurtir.classList.add('curtido');
            icone.textContent = '❤️';
            texto.textContent = 'Curtido';
        } else {
            btnCurtir.classList.remove('curtido');
            icone.textContent = '🤍';
            texto.textContent = 'Curtir';
        }

        contador.textContent = this.totalCurtidas;

        // Animação
        btnCurtir.classList.add('animacao-curtida');
        setTimeout(() => {
            btnCurtir.classList.remove('animacao-curtida');
        }, 300);
    }

    // ========== COMENTÁRIOS ==========

    /**
     * Inicializar sistema de comentários
     */
    async inicializarComentarios(containerId = 'comentarios-container') {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Criar estrutura HTML
        container.innerHTML = `
            <div class="comentarios-wrapper">
                <h3 class="comentarios-titulo">
                    💬 Comentários 
                    <span class="comentarios-count" id="comentariosCount">0</span>
                </h3>
                
                <div class="comentario-form-wrapper">
                    <form id="formComentario" class="comentario-form">
                        <textarea 
                            id="comentarioTexto" 
                            name="comentario" 
                            placeholder="Deixe seu comentário..." 
                            rows="3"
                            maxlength="1000"
                            required
                        ></textarea>
                        <div class="comentario-form-footer">
                            <small class="contador-caracteres">
                                <span id="charCount">0</span>/1000 caracteres
                            </small>
                            <button type="submit" class="btn-comentar">
                                📝 Publicar Comentário
                            </button>
                        </div>
                    </form>
                </div>
                
                <div class="comentarios-lista" id="comentariosLista">
                    <p class="loading-comentarios">Carregando comentários...</p>
                </div>
            </div>
        `;

        // Event listeners
        document.getElementById('formComentario').addEventListener('submit', (e) => {
            e.preventDefault();
            this.publicarComentario();
        });

        document.getElementById('comentarioTexto').addEventListener('input', (e) => {
            document.getElementById('charCount').textContent = e.target.value.length;
        });

        // Carregar comentários existentes
        await this.carregarComentarios();
    }

    /**
     * Carregar comentários do artigo
     */
    async carregarComentarios() {
        const lista = document.getElementById('comentariosLista');
        if (!lista) return;

        try {
            const response = await fetch(`processa_interacoes.php?acao=obter_comentarios&artigo_id=${this.artigoId}`);
            
            if (!response.ok) {
                console.error('Erro HTTP:', response.status);
                this.comentarios = [];
                const contador = document.getElementById('comentariosCount');
                if (contador) contador.textContent = '0';
                this.renderizarComentarios();
                return;
            }
            
            const data = await response.json();
            
            // Garantir que this.comentarios seja sempre um array
            if (Array.isArray(data)) {
                this.comentarios = data;
            } else {
                console.warn('Resposta não é um array:', data);
                this.comentarios = [];
            }

            // Atualizar contador
            const contador = document.getElementById('comentariosCount');
            if (contador) {
                contador.textContent = this.comentarios.length;
            }

            // Renderizar comentários
            this.renderizarComentarios();

        } catch (erro) {
            console.error('Erro ao carregar comentários:', erro);
            this.comentarios = [];
            this.renderizarComentarios();
            lista.innerHTML = '<p class="erro-comentarios">Erro ao carregar comentários.</p>';
        }
    }

    /**
     * Renderizar lista de comentários
     */
    renderizarComentarios() {
        const lista = document.getElementById('comentariosLista');
        if (!lista) return;

        if (this.comentarios.length === 0) {
            lista.innerHTML = `
                <div class="sem-comentarios">
                    <p>💭 Seja o primeiro a comentar!</p>
                </div>
            `;
            return;
        }

        lista.innerHTML = '';

        this.comentarios.forEach(comentario => {
            const comentarioElement = this.criarElementoComentario(comentario);
            lista.appendChild(comentarioElement);
        });
    }

    /**
     * Criar elemento HTML de um comentário
     */
    criarElementoComentario(comentario) {
        const div = document.createElement('div');
        div.className = 'comentario-item';
        div.dataset.comentarioId = comentario.ID;

        const dataFormatada = this.formatarData(comentario.DATA_COMENTARIO);
        const editadoLabel = comentario.EDITADO ? ' <span class="editado-label">(editado)</span>' : '';

        // Verificar se é o autor do comentário
        const isAutor = this.verificarAutorComentario(comentario.USUARIO_ID);

        div.innerHTML = `
            <div class="comentario-header">
                <div class="comentario-usuario">
                    <span class="usuario-avatar">👤</span>
                    <span class="usuario-nome">${this.escapeHtml(comentario.AUTOR_NOME)}</span>
                </div>
                <div class="comentario-info">
                    <span class="comentario-data">${dataFormatada}</span>
                    ${editadoLabel}
                </div>
            </div>
            <div class="comentario-corpo">
                <p class="comentario-texto">${this.escapeHtml(comentario.CONTEUDO)}</p>
            </div>
            ${isAutor ? `
                <div class="comentario-acoes">
                    <button class="btn-editar-comentario" onclick="window.interacoes.editarComentario(${comentario.ID})">
                        ✏️ Editar
                    </button>
                    <button class="btn-excluir-comentario" onclick="window.interacoes.excluirComentario(${comentario.ID})">
                        🗑️ Excluir
                    </button>
                </div>
            ` : ''}
        `;

        return div;
    }

    /**
     * Publicar novo comentário
     */
    async publicarComentario() {
        const textarea = document.getElementById('comentarioTexto');
        const btnSubmit = document.querySelector('.btn-comentar');
        const comentario = textarea.value.trim();

        if (comentario.length < 3) {
            this.mostrarFeedback('Comentário muito curto! Mínimo 3 caracteres.', 'error');
            return;
        }

        btnSubmit.disabled = true;
        btnSubmit.textContent = '📤 Publicando...';

        try {
            const response = await fetch('processa_interacoes.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `acao=comentar&artigo_id=${this.artigoId}&comentario=${encodeURIComponent(comentario)}`
            });

            const resultado = await response.json();

            // Verificar se usuário não está autenticado
            if (response.status === 401 || resultado.redirect) {
                // Salvar URL atual para retornar após login
                const urlAtual = window.location.href;
                const loginUrl = resultado.redirect || 'login.html';
                
                // Mostrar mensagem antes de redirecionar
                this.mostrarFeedback('❌ Você precisa estar logado para comentar!', 'error');
                
                // Redirecionar após 1.5 segundos
                setTimeout(() => {
                    window.location.href = loginUrl + '?redirect=' + encodeURIComponent(urlAtual);
                }, 1500);
                return;
            }

            if (resultado.sucesso) {
                this.mostrarFeedback(resultado.mensagem, 'success');
                
                // Limpar textarea
                textarea.value = '';
                document.getElementById('charCount').textContent = '0';

                // Recarregar comentários
                await this.carregarComentarios();

            } else {
                this.mostrarFeedback(resultado.mensagem || 'Erro ao publicar comentário', 'error');
            }

        } catch (erro) {
            console.error('Erro ao publicar comentário:', erro);
            this.mostrarFeedback('Erro ao publicar comentário', 'error');
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.textContent = '📝 Publicar Comentário';
        }
    }

    /**
     * Editar comentário
     */
    async editarComentario(comentarioId) {
        const comentarioElement = document.querySelector(`[data-comentario-id="${comentarioId}"]`);
        if (!comentarioElement) return;

        const textoAtual = comentarioElement.querySelector('.comentario-texto').textContent;

        const novoTexto = prompt('Editar comentário:', textoAtual);
        
        if (novoTexto === null) return;
        if (novoTexto.trim().length < 3) {
            this.mostrarFeedback('Comentário muito curto!', 'error');
            return;
        }

        try {
            const response = await fetch('processa_interacoes.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `acao=editar_comentario&comentario_id=${comentarioId}&comentario=${encodeURIComponent(novoTexto)}`
            });

            const resultado = await response.json();

            // Verificar se usuário não está autenticado
            if (response.status === 401 || response.status === 403) {
                this.mostrarFeedback('❌ Você não tem permissão para editar este comentário', 'error');
                return;
            }

            if (resultado.sucesso) {
                this.mostrarFeedback(resultado.mensagem, 'success');
                await this.carregarComentarios();
            } else {
                this.mostrarFeedback(resultado.mensagem || 'Erro ao editar comentário', 'error');
            }

        } catch (erro) {
            console.error('Erro ao editar comentário:', erro);
            this.mostrarFeedback('Erro ao editar comentário', 'error');
        }
    }

    /**
     * Excluir comentário
     */
    async excluirComentario(comentarioId) {
        if (!confirm('Tem certeza que deseja excluir este comentário?')) {
            return;
        }

        try {
            const response = await fetch('processa_interacoes.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `acao=deletar_comentario&comentario_id=${comentarioId}`
            });

            const resultado = await response.json();

            // Verificar se usuário não está autenticado ou sem permissão
            if (response.status === 401 || response.status === 403) {
                this.mostrarFeedback('❌ Você não tem permissão para excluir este comentário', 'error');
                return;
            }

            if (resultado.sucesso) {
                this.mostrarFeedback(resultado.mensagem, 'success');
                await this.carregarComentarios();
            } else {
                this.mostrarFeedback(resultado.mensagem || 'Erro ao excluir comentário', 'error');
            }

        } catch (erro) {
            console.error('Erro ao excluir comentário:', erro);
            this.mostrarFeedback('Erro ao excluir comentário', 'error');
        }
    }

    // ========== FUNÇÕES AUXILIARES ==========

    /**
     * Verificar se o usuário é o autor do comentário
     */
    verificarAutorComentario(usuarioIdComentario) {
        return this.usuarioLogadoId === usuarioIdComentario;
    }

    /**
     * Formatar data
     */
    formatarData(dataString) {
        const data = new Date(dataString);
        const agora = new Date();
        const diferenca = agora - data;

        if (diferenca < 60000) {
            return 'Agora mesmo';
        }

        if (diferenca < 3600000) {
            const minutos = Math.floor(diferenca / 60000);
            return `${minutos} ${minutos === 1 ? 'minuto' : 'minutos'} atrás`;
        }

        if (diferenca < 86400000) {
            const horas = Math.floor(diferenca / 3600000);
            return `${horas} ${horas === 1 ? 'hora' : 'horas'} atrás`;
        }

        if (diferenca < 604800000) {
            const dias = Math.floor(diferenca / 86400000);
            return `${dias} ${dias === 1 ? 'dia' : 'dias'} atrás`;
        }

        return data.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    /**
     * Escapar HTML para prevenir XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Mostrar mensagem de feedback
     */
    mostrarFeedback(mensagem, tipo) {
        const feedback = document.createElement('div');
        feedback.className = `feedback-message ${tipo === 'success' ? 'success-message' : 'error-message'}`;
        feedback.textContent = mensagem;
        feedback.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(feedback);

        setTimeout(() => {
            feedback.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => feedback.remove(), 300);
        }, 3000);
    }
}

// Instância global (será inicializada na página do artigo)
let interacoes;

// ========== FUNÇÕES HERBÁRIO ==========

const emojis = {
    plantas: ['🌿', '🌱', '🪴', '🌾', '🌴', '🎋', '🎍', '🌲', '🌳', '🌵', '🍀', '☘️'],
    flores: ['🌸', '🌺', '🌻', '🌹', '🥀', '🌵️', '🌷', '🌼', '💐', '🏵️'],
    frutas: ['🍎', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍑', '🍒', '🥭'],
    vegetais: ['🥬', '🥒', '🥕', '🌽', '🌶️', '🫑', '🥔', '🍆', '🧄', '🧅', '🥦', '🫛']
};

function abrirSeletorEmoji() {
    document.getElementById('modalEmoji').style.display = 'flex';
    setTimeout(() => {
        const primeiroBtn = document.querySelector('.emoji-cat-btn');
        if (primeiroBtn) {
            primeiroBtn.click();
        }
    }, 100);
}

function fecharSeletorEmoji() {
    document.getElementById('modalEmoji').style.display = 'none';
}

function filtrarEmojis(categoria) {
    const grid = document.getElementById('emojiGrid');
    const botoes = document.querySelectorAll('.emoji-cat-btn');
    
    botoes.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    grid.innerHTML = '';
    emojis[categoria].forEach(emoji => {
        const div = document.createElement('div');
        div.className = 'emoji-item';
        div.textContent = emoji;
        div.onclick = () => selecionarEmoji(emoji);
        grid.appendChild(div);
    });
}

function selecionarEmoji(emoji) {
    const preview = document.getElementById('imagemPreview');
    preview.innerHTML = `
        <span class="emoji-display">${emoji}</span>
        <p class="imagem-hint">Emoji selecionado</p>
    `;
    document.getElementById('tipoImagem').value = 'emoji';
    document.getElementById('valorImagem').value = emoji;
    document.getElementById('btnLimparImagem').style.display = 'inline-block';
    fecharSeletorEmoji();
}

function previewImagem(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        alert('❌ Apenas imagens são permitidas!');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        alert('❌ Imagem muito grande! Máximo 5MB.');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('imagemPreview');
        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        document.getElementById('tipoImagem').value = 'imagem';
        document.getElementById('btnLimparImagem').style.display = 'inline-block';
    };
    reader.readAsDataURL(file);
}

function limparImagem() {
    const preview = document.getElementById('imagemPreview');
    preview.innerHTML = `
        <span class="emoji-display">🌿</span>
        <p class="imagem-hint">Clique para adicionar</p>
    `;
    document.getElementById('inputImagem').value = '';
    document.getElementById('tipoImagem').value = 'emoji';
    document.getElementById('valorImagem').value = '🌿';
    document.getElementById('btnLimparImagem').style.display = 'none';
}

/**
 * Script para o Herbário Digital
 * Carrega e filtra plantas do banco de dados
 */

// Estado global
let todasPlantas = [];
let categorias = {};

// Carregar categorias e plantas ao carregar a página
document.addEventListener('DOMContentLoaded', function() {
    carregarTodosDados(); // Carrega tudo de uma vez (otimizado)
    
    // Event listeners para filtros
    document.getElementById('filtroTipo').addEventListener('change', filtrarPlantas);
    document.getElementById('filtroUtilidade').addEventListener('change', filtrarPlantas);
    document.getElementById('buscarPlanta').addEventListener('input', filtrarPlantas);
});

/**
 * Carregar todos os dados de uma vez (plantas + categorias)
 * Método otimizado - apenas 1 requisição
 */
async function carregarTodosDados() {
    try {
        mostrarCarregando();
        
        const response = await fetch('get_plantas.php?action=todas');
        const data = await response.json();
        
        if (data.success) {
            // Salvar categorias
            categorias = data.categorias;
            popularFiltros();
            
            // Salvar e exibir plantas
            todasPlantas = data.plantas;
            exibirPlantas(todasPlantas);
            atualizarTotal(data.total);
        } else {
            mostrarErro('Erro ao carregar dados: ' + data.error);
        }
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
        mostrarErro('Erro ao conectar com o servidor');
    }
}

/**
 * Carregar categorias do banco
 */
async function carregarCategorias() {
    try {
        const response = await fetch('get_plantas.php?action=categorias&categoria=todas');
        const data = await response.json();
        
        if (data.success) {
            categorias = data.categorias;
            popularFiltros();
        } else {
            console.error('Erro ao carregar categorias:', data.error);
        }
    } catch (error) {
        console.error('Erro na requisição de categorias:', error);
    }
}

/**
 * Popular os selects de filtro com as categorias
 */
function popularFiltros() {
    // Popular filtro de tipos
    const filtroTipo = document.getElementById('filtroTipo');
    filtroTipo.innerHTML = '<option value="">Todos os tipos</option>';
    categorias.tipos.forEach(tipo => {
        filtroTipo.innerHTML += `<option value="${tipo.ID}">${tipo.NOME}</option>`;
    });
    
    // Popular filtro de utilidades
    const filtroUtilidade = document.getElementById('filtroUtilidade');
    filtroUtilidade.innerHTML = '<option value="">Todas as utilidades</option>';
    categorias.utilidades.forEach(utilidade => {
        filtroUtilidade.innerHTML += `<option value="${utilidade.ID}">${utilidade.NOME}</option>`;
    });
}

/**
 * Carregar todas as plantas do banco
 */
async function carregarPlantas() {
    try {
        mostrarCarregando();
        
        const response = await fetch('get_plantas.php?action=plantas');
        const data = await response.json();
        
        if (data.success) {
            todasPlantas = data.plantas;
            exibirPlantas(todasPlantas);
            atualizarTotal(data.total);
        } else {
            mostrarErro('Erro ao carregar plantas: ' + data.error);
        }
    } catch (error) {
        console.error('Erro ao carregar plantas:', error);
        mostrarErro('Erro ao conectar com o servidor');
    }
}

/**
 * Exibir plantas no grid
 */
function exibirPlantas(plantas) {
    const grid = document.getElementById('plantasGrid');
    
    if (plantas.length === 0) {
        grid.innerHTML = `
            <div class="mensagem-vazia">
                <p>🌱 Nenhuma planta encontrada com os filtros selecionados.</p>
            </div>
        `;
        return;
    }
    
    grid.innerHTML = plantas.map(planta => `
        <div class="planta-card" 
             data-tipo-id="${planta.tipoId || ''}" 
             data-uti-id="${planta.utiId || ''}"
             data-nome="${planta.nomeCientifico}">
            <div class="planta-imagem">
                <div class="sem-imagem">🌿</div>
            </div>
            <div class="planta-info">
                <h3>${planta.nomeCientifico}</h3>
                <p class="planta-nome-popular">${planta.nomePopular || 'Nome popular não informado'}</p>
                <div class="planta-tags">
                    ${planta.tipo ? `<span class="tag tag-tipo">${planta.tipo}</span>` : ''}
                    ${planta.utilidade ? `<span class="tag tag-utilidade">${planta.utilidade}</span>` : ''}
                </div>
                <div class="planta-info-extra">
                    ${planta.tamanho ? `<p>📏 Tamanho: ${planta.tamanho}m</p>` : ''}
                    ${planta.horasSol ? `<p>☀️ Sol: ${planta.horasSol}h/dia</p>` : ''}
                    ${planta.solo ? `<p>🌱 Solo: ${planta.solo}</p>` : ''}
                    ${planta.clima ? `<p>🌡️ Clima: ${planta.clima}</p>` : ''}
                </div>
                <button onclick="verDetalhes(${planta.id})" class="btn btn-secondary">
                    Ver Detalhes
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Filtrar plantas baseado nos filtros selecionados
 */
function filtrarPlantas() {
    const tipoSelecionado = document.getElementById('filtroTipo').value;
    const utilidadeSelecionada = document.getElementById('filtroUtilidade').value;
    const termoBusca = document.getElementById('buscarPlanta').value.toLowerCase();
    
    const plantasFiltradas = todasPlantas.filter(planta => {
        // Filtrar por tipo (usando ID)
        if (tipoSelecionado && planta.tipoId != tipoSelecionado) {
            return false;
        }
        
        // Filtrar por utilidade (usando ID)
        if (utilidadeSelecionada && planta.utiId != utilidadeSelecionada) {
            return false;
        }
        
        // Filtrar por busca
        if (termoBusca) {
            const nomeC = (planta.nomeCientifico || '').toLowerCase();
            const nomeP = (planta.nomePopular || '').toLowerCase();
            if (!nomeC.includes(termoBusca) && !nomeP.includes(termoBusca)) {
                return false;
            }
        }
        
        return true;
    });
    
    exibirPlantas(plantasFiltradas);
    atualizarTotal(plantasFiltradas.length);
}

/**
 * Ver detalhes de uma planta
 */
function verDetalhes(id) {
    window.location.href = `detalhes-planta.html?id=${id}`;
}

/**
 * Mostrar indicador de carregamento
 */
function mostrarCarregando() {
    const grid = document.getElementById('plantasGrid');
    grid.innerHTML = `
        <div class="carregando">
            <div class="spinner"></div>
            <p>Carregando plantas...</p>
        </div>
    `;
}

/**
 * Mostrar mensagem de erro
 */
function mostrarErro(mensagem) {
    const grid = document.getElementById('plantasGrid');
    grid.innerHTML = `
        <div class="mensagem-erro">
            <p>⚠️ ${mensagem}</p>
            <button onclick="carregarPlantas()" class="btn btn-primary">Tentar Novamente</button>
        </div>
    `;
}

/**
 * Atualizar contador de plantas
 */
function atualizarTotal(total) {
    document.getElementById('totalPlantas').textContent = total;
}

/**
 * Truncar texto longo
 */
function truncarTexto(texto, maxLength) {
    if (!texto) return 'Sem descrição disponível';
    if (texto.length <= maxLength) return texto;
    return texto.substring(0, maxLength) + '...';
}
// ========== FUNÇÕES NOTÍCIAS ==========

function previewImagemNoticia(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    if (!file.type.startsWith('image/')) {
        alert('❌ Apenas imagens são permitidas!');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) {
        alert('❌ Imagem muito grande! Máximo 5MB.');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('imagemPreviewNoticia');
        preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        document.getElementById('btnLimparImagemNoticia').style.display = 'inline-block';
    };
    reader.readAsDataURL(file);
}

function limparImagemNoticia() {
    const preview = document.getElementById('imagemPreviewNoticia');
    preview.innerHTML = `
        <span class="emoji-display">📰</span>
        <p class="imagem-hint">Clique para adicionar imagem</p>
    `;
    document.getElementById('inputImagemNoticia').value = '';
    document.getElementById('btnLimparImagemNoticia').style.display = 'none';
}

async function carregarNoticias() {
    const lista = document.getElementById('listaNoticias');
    if (!lista) return;
    
    lista.innerHTML = '<p style="text-align: center; color: #666;">Carregando notícias...</p>';
    
    try {
        const response = await fetch('listar_artigos.php');
        
        if (!response.ok) {
            throw new Error('Erro ao carregar');
        }
        
        const artigos = await response.json();
        
        if (artigos.length === 0) {
            lista.innerHTML = '<p style="text-align: center; color: #666;">Nenhuma notícia publicada ainda.</p>';
            return;
        }
        
        lista.innerHTML = '';
        
        artigos.forEach(artigo => {
            const item = document.createElement('div');
            item.className = 'admin-item';
            
            const dataFormatada = new Date(artigo.DATA).toLocaleDateString('pt-BR');
            const imagem = artigo.IMAGEM ? 
                `<img src="${artigo.IMAGEM}" alt="${artigo.TITULO}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px; margin-right: 1rem;">` : 
                '<span style="font-size: 2rem; margin-right: 1rem;">📰</span>';
            
            item.innerHTML = `
                <div style="display: flex; align-items: center; gap: 1rem; flex: 1;">
                    ${imagem}
                    <div>
                        <strong style="color: #1a4d2e;">${artigo.TITULO}</strong><br>
                        <small style="color: #666;">📅 ${dataFormatada} | ✏️ ${artigo.AUTOR || 'Autor Desconhecido'}</small>
                    </div>
                </div>
                <div class="admin-actions">
                    <button class="btn-edit" onclick="editarNoticia(${artigo.ID})">✏️ Editar</button>
                    <button class="btn-delete" onclick="excluirNoticia(${artigo.ID})">🗑️ Excluir</button>
                </div>
            `;
            
            lista.appendChild(item);
        });
        
    } catch (erro) {
        console.error('Erro ao carregar notícias:', erro);
        lista.innerHTML = '<p style="text-align: center; color: #dc3545;">Erro ao carregar notícias.</p>';
    }
}

function editarNoticia(id) {
    alert('Função de edição em desenvolvimento. ID: ' + id);
}

async function excluirNoticia(id) {
    if (!confirm('Deseja realmente excluir esta notícia/artigo?')) return;
    
    try {
        const response = await fetch('processa_artigo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `acao=excluir&id=${id}`
        });
        
        const resultado = await response.json();
        
        if (resultado.sucesso) {
            mostrarMensagem('success', resultado.mensagem);
            carregarNoticias();
        } else {
            mostrarMensagem('error', resultado.mensagem);
        }
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarMensagem('error', 'Erro ao excluir notícia!');
    }
}

// Submeter formulário de notícia
document.addEventListener('DOMContentLoaded', () => {
    const formNoticia = document.getElementById('formNoticia');
    if (formNoticia) {
        formNoticia.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('acao', 'criar');
            
            try {
                const response = await fetch('processa_artigo.php', {
                    method: 'POST',
                    body: formData
                });
                
                const resultado = await response.json();
                
                if (resultado.sucesso) {
                    mostrarMensagem('success', resultado.mensagem);
                    this.reset();
                    limparImagemNoticia();
                    carregarNoticias();
                } else {
                    mostrarMensagem('error', resultado.mensagem);
                }
            } catch (erro) {
                console.error('Erro:', erro);
                mostrarMensagem('error', 'Erro ao publicar notícia!');
            }
        });
    }
});

// ========== FUNÇÕES PAINEL ADMIN - GERENCIAMENTO DE USUÁRIOS ==========

let todosUsuarios = [];

// Carregar usuários ao iniciar a página (se estiver no painel admin)
if (document.getElementById('listaUsuarios')) {
    window.addEventListener('DOMContentLoaded', () => {
        carregarUsuarios();
    });
}

async function carregarUsuarios() {
    const lista = document.getElementById('listaUsuarios');
    if (!lista) return;
    
    const filtroTipo = document.getElementById('filtroTipoUsuario')?.value || '';
    
    lista.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #666; padding: 2rem;">Carregando usuários...</td></tr>';
    
    try {
        let url = 'listar_usuarios.php';
        if (filtroTipo !== '') {
            url += '?tipo=' + filtroTipo;
        }
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        todosUsuarios = await response.json();
        console.log('Usuários carregados:', todosUsuarios);
        renderizarUsuarios(todosUsuarios);
        
    } catch (erro) {
        console.error('Erro ao carregar usuários:', erro);
        lista.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #dc3545; padding: 2rem;">❌ Erro ao carregar usuários. Verifique o console.</td></tr>';
    }
}

function filtrarUsuarios() {
    const termoBusca = document.getElementById('buscaUsuario')?.value.toLowerCase() || '';
    
    if (termoBusca === '') {
        renderizarUsuarios(todosUsuarios);
        return;
    }
    
    const usuariosFiltrados = todosUsuarios.filter(usuario => 
        usuario.NOME.toLowerCase().includes(termoBusca) ||
        usuario.EMAIL.toLowerCase().includes(termoBusca)
    );
    
    renderizarUsuarios(usuariosFiltrados);
}

function renderizarUsuarios(usuarios) {
    const tbody = document.getElementById('listaUsuarios');
    if (!tbody) return;
    
    if (!usuarios || usuarios.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #666; padding: 2rem;">Nenhum usuário encontrado.</td></tr>';
        return;
    }
    
    tbody.innerHTML = '';
    
    usuarios.forEach(usuario => {
        const tr = document.createElement('tr');
        
        const tipoNome = getTipoUsuarioNome(usuario.TIPO_USUARIO);
        const tipoClass = getTipoUsuarioClass(usuario.TIPO_USUARIO);
        const isAdmin = usuario.TIPO_USUARIO == 1;
        
        tr.innerHTML = `
            <td class="nome-cell">👤 ${usuario.NOME}</td>
            <td class="email-cell">${usuario.EMAIL}</td>
            <td class="tipo-cell">
                <span class="badge-tipo-small ${tipoClass}-small">${tipoNome}</span>
            </td>
            <td class="acoes-cell">
                ${!isAdmin ? `
                    <div class="btn-group">
                        ${usuario.TIPO_USUARIO == 2 ? `
                            <button class="btn-small btn-remover" onclick="removerAutor(${usuario.ID})" title="Remover Autor">
                                ⬇️
                            </button>
                        ` : `
                            <button class="btn-small btn-promover" onclick="promoverAutor(${usuario.ID})" title="Promover a Autor">
                                ⬆️
                            </button>
                        `}
                        <button class="btn-small btn-excluir" onclick="excluirUsuario(${usuario.ID})" title="Excluir">
                            🗑️
                        </button>
                    </div>
                ` : `
                    <span style="color: #666; font-size: 0.85rem;">👑 Admin</span>
                `}
            </td>
        `;
        
        tbody.appendChild(tr);
    });
}

function getTipoUsuarioNome(tipo) {
    if (tipo === null || tipo === undefined || tipo === '') {
        return 'Usuário Comum';
    }
    const tipoNum = parseInt(tipo);
    if (isNaN(tipoNum)) {
        return 'Usuário Comum';
    }
    switch(tipoNum) {
        case 0: return 'Usuário Comum';
        case 1: return 'Administrador';
        case 2: return 'Autor';
        default: return 'Usuário Comum';
    }
}

function getTipoUsuarioClass(tipo) {
    if (tipo === null || tipo === undefined || tipo === '') {
        return 'badge-usuario';
    }
    const tipoNum = parseInt(tipo);
    if (isNaN(tipoNum)) {
        return 'badge-usuario';
    }
    switch(tipoNum) {
        case 0: return 'badge-usuario';
        case 1: return 'badge-admin';
        case 2: return 'badge-autor';
        default: return 'badge-usuario';
    }
}

async function promoverAutor(usuarioId) {
    if (!confirm('Promover este usuário a AUTOR?\n\nComo autor, ele poderá escrever e publicar artigos.')) return;
    
    try {
        const response = await fetch('gerenciar_usuarios.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `acao=promover_autor&usuario_id=${usuarioId}`
        });
        
        const resultado = await response.json();
        
        if (resultado.sucesso) {
            mostrarMensagem('success', resultado.mensagem);
            carregarUsuarios();
        } else {
            mostrarMensagem('error', resultado.mensagem);
        }
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarMensagem('error', 'Erro ao promover usuário!');
    }
}

async function removerAutor(usuarioId) {
    if (!confirm('Remover permissões de AUTOR deste usuário?')) return;
    
    try {
        const response = await fetch('gerenciar_usuarios.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `acao=remover_autor&usuario_id=${usuarioId}`
        });
        
        const resultado = await response.json();
        
        if (resultado.sucesso) {
            mostrarMensagem('success', resultado.mensagem);
            carregarUsuarios();
        } else {
            mostrarMensagem('error', resultado.mensagem);
        }
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarMensagem('error', 'Erro ao remover autor!');
    }
}

async function excluirUsuario(usuarioId) {
    if (!confirm('⚠️ ATENÇÃO!\n\nDeseja realmente EXCLUIR este usuário?\n\nEsta ação é IRREVERSÍVEL!')) return;
    
    try {
        const response = await fetch('gerenciar_usuarios.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `acao=excluir&usuario_id=${usuarioId}`
        });
        
        const resultado = await response.json();
        
        if (resultado.sucesso) {
            mostrarMensagem('success', resultado.mensagem);
            carregarUsuarios();
        } else {
            mostrarMensagem('error', resultado.mensagem);
        }
    } catch (erro) {
        console.error('Erro:', erro);
        mostrarMensagem('error', 'Erro ao excluir usuário!');
    }
}
                    
// ========== CARREGAR ARTIGOS NA PÁGINA INICIAL (integrado de noticias.js) ==========

// Verificar se estamos na página inicial e carregar artigos
document.addEventListener('DOMContentLoaded', () => {
    // Verificar se estamos na página inicial
    if (document.querySelector('.noticias-grid')) {
        carregarArtigosHome();
    }
});

async function carregarArtigosHome() {
    const grid = document.querySelector('.noticias-grid');
    
    if (!grid) return;
    
    // Mostrar loading
    grid.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
            <p style="color: #666; font-size: 1.1rem;">📰 Carregando artigos...</p>
        </div>
    `;
    
    try {
        const response = await fetch('listar_artigos_publicos.php?limite=6');
        
        if (!response.ok) {
            throw new Error('Erro ao carregar artigos');
        }
        
        const artigos = await response.json();
        
        if (artigos.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                    <p style="color: #666; font-size: 1.1rem;">📝 Nenhum artigo publicado ainda.</p>
                    <p style="color: #999; margin-top: 0.5rem;">Em breve teremos novidades!</p>
                </div>
            `;
            return;
        }
        
        // Limpar grid
        grid.innerHTML = '';
        
        // Renderizar artigos
        artigos.forEach((artigo, index) => {
            const card = criarCardArtigoHome(artigo, index === 0);
            grid.appendChild(card);
        });
        
    } catch (erro) {
        console.error('Erro ao carregar artigos:', erro);
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                <p style="color: #dc3545; font-size: 1.1rem;">❌ Erro ao carregar artigos</p>
                <p style="color: #999; margin-top: 0.5rem;">Tente recarregar a página</p>
            </div>
        `;
    }
}

function criarCardArtigoHome(artigo, isFeatured = false) {
    const card = document.createElement('div');
    card.className = isFeatured ? 'noticia-card featured' : 'noticia-card';
    
    // Formatar data
    const data = new Date(artigo.DATA + 'T00:00:00');
    const dataFormatada = data.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });
    
    // Criar resumo (usar subtítulo se existir, senão usar resumo do corpo)
    const descricao = artigo.SUBTITULO || artigo.RESUMO;
    
    card.innerHTML = `
        <div class="noticia-imagem-container">
            <div class="noticia-imagem-placeholder">
                📰
            </div>
            ${isFeatured ? '<span class="badge-destaque">✨ Destaque</span>' : ''}
        </div>
        <div class="noticia-content">
            <div class="noticia-meta">
                <span class="noticia-autor">✍️ ${escapeHtmlText(artigo.AUTOR)}</span>
                <span class="noticia-data">📅 ${dataFormatada}</span>
            </div>
            <h3 class="noticia-titulo">${escapeHtmlText(artigo.TITULO)}</h3>
            <p class="noticia-descricao">${escapeHtmlText(descricao)}</p>
            <div class="noticia-footer">
                <div class="noticia-stats">
                    <span title="Curtidas">❤️ ${artigo.TOTAL_CURTIDAS}</span>
                    <span title="Comentários">💬 ${artigo.TOTAL_COMENTARIOS}</span>
                </div>
                <a href="artigo.php?id=${artigo.ID}" class="noticia-link">
                    Leia mais →
                </a>
            </div>
        </div>
    `;
    
    return card;
}

function escapeHtmlText(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
