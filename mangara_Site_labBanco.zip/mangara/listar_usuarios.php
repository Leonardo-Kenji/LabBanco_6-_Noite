<?php
// ========== LISTAR USUÁRIOS - VERSÃO CORRIGIDA ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se está autenticado como admin
if (!estaAutenticadoComoAdmin()) {
    http_response_code(403);
    echo json_encode(['erro' => 'Acesso negado']);
    exit;
}

try {
    // Verificar se há filtro por tipo
    $tipoFiltro = isset($_GET['tipo']) ? $_GET['tipo'] : null;
    
    // Log para debug
    error_log("Filtro de tipo recebido: " . ($tipoFiltro === null ? 'null' : $tipoFiltro));

    // Preparar query - COALESCE garante que TIPO_USUARIO nunca seja NULL
    if ($tipoFiltro !== null && $tipoFiltro !== '') {
        $tipoFiltroInt = intval($tipoFiltro);
        
        $stmt = $conexao->prepare(
            "SELECT 
                ID, 
                NOME, 
                EMAIL, 
                COALESCE(TIPO_USUARIO, 0) as TIPO_USUARIO, 
                DATANASCIMENTO 
             FROM MANGA.USUARIO 
             WHERE COALESCE(TIPO_USUARIO, 0) = ?
             ORDER BY NOME ASC"
        );
        
        if (!$stmt) {
            throw new Exception('Erro na preparação da query: ' . $conexao->error);
        }
        
        $stmt->bind_param("i", $tipoFiltroInt);
        error_log("Buscando usuários com tipo: $tipoFiltroInt");
        
    } else {
        // Sem filtro - buscar todos
        $stmt = $conexao->prepare(
            "SELECT 
                ID, 
                NOME, 
                EMAIL, 
                COALESCE(TIPO_USUARIO, 0) as TIPO_USUARIO, 
                DATANASCIMENTO 
             FROM MANGA.USUARIO 
             ORDER BY COALESCE(TIPO_USUARIO, 0) DESC, NOME ASC"
        );
        
        if (!$stmt) {
            throw new Exception('Erro na preparação da query: ' . $conexao->error);
        }
        
        error_log("Buscando todos os usuários");
    }

    $stmt->execute();
    $resultado = $stmt->get_result();

    $usuarios = [];
    while ($row = $resultado->fetch_assoc()) {
        // Garantir que TIPO_USUARIO seja sempre um número válido
        $row['TIPO_USUARIO'] = intval($row['TIPO_USUARIO']);
        $usuarios[] = $row;
    }

    $stmt->close();
    
    error_log("Total de usuários encontrados: " . count($usuarios));

    echo json_encode($usuarios);
    
} catch (Exception $e) {
    error_log("Erro em listar_usuarios.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['erro' => $e->getMessage()]);
}

exit;
?>