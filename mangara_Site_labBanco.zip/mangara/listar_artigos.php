<?php
// ========== LISTAR ARTIGOS ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se está autenticado
if (!estaAutenticado()) {
    http_response_code(401);
    echo json_encode([]);
    exit;
}

$usuarioId = getUsuarioLogadoId();
$isAdmin = estaAutenticadoComoAdmin();

// Verificar o tipo de listagem
if (isset($_GET['meus'])) {
    // Listar apenas artigos do usuário logado
    $stmt = $conexao->prepare(
        "SELECT ID, TITULO, SUBTITULO, AUTOR, DATA 
         FROM MANGA.ARTIGO 
         WHERE AUTOR_ID = ? 
         ORDER BY DATA DESC, ID DESC"
    );
    $stmt->bind_param("i", $usuarioId);
    
} elseif (isset($_GET['todos']) && $isAdmin) {
    // Listar todos os artigos (apenas admin)
    $stmt = $conexao->prepare(
        "SELECT ID, TITULO, SUBTITULO, AUTOR, DATA 
         FROM MANGA.ARTIGO 
         ORDER BY DATA DESC, ID DESC"
    );
    
} else {
    // Listar artigos públicos (para exibição no site)
    $stmt = $conexao->prepare(
        "SELECT ID, TITULO, SUBTITULO, AUTOR, DATA 
         FROM MANGA.ARTIGO 
         ORDER BY DATA DESC, ID DESC"
    );
}

if (!$stmt) {
    http_response_code(500);
    echo json_encode([]);
    exit;
}

$stmt->execute();
$resultado = $stmt->get_result();

$artigos = [];
while ($row = $resultado->fetch_assoc()) {
    $artigos[] = $row;
}

$stmt->close();

echo json_encode($artigos);
exit;
?>