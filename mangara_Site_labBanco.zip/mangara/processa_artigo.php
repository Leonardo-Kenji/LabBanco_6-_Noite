<?php
// ========== PROCESSA ARTIGO ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se está autenticado
if (!estaAutenticado()) {
    http_response_code(401);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Você precisa estar autenticado!']);
    exit;
}

// Verificar se pode escrever artigos
if (!podeEscreverArtigos()) {
    http_response_code(403);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Você não tem permissão para escrever artigos!']);
    exit;
}

// Verifica se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $acao = isset($_POST['acao']) ? $_POST['acao'] : '';
    
    // ========== CRIAR ARTIGO ==========
    if ($acao === 'criar') {
        
        $titulo = isset($_POST['titulo']) ? trim($_POST['titulo']) : '';
        $subtitulo = isset($_POST['subtitulo']) ? trim($_POST['subtitulo']) : '';
        $corpo = isset($_POST['corpo']) ? trim($_POST['corpo']) : '';
        $referencias = isset($_POST['referencias']) ? trim($_POST['referencias']) : '';
        
        // Validações
        if (empty($titulo) || empty($corpo)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Título e corpo são obrigatórios!']);
            exit;
        }
        
        // Obter ID e nome do usuário logado (autor)
        $autorId = getUsuarioLogadoId();
        $autorNome = getUsuarioLogadoNome();
        
        if (!$autorId || !$autorNome) {
            http_response_code(401);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao identificar o autor!']);
            exit;
        }
        
        // Data atual
        $data = date('Y-m-d');
        
        // Inserir artigo no banco
        $stmt = $conexao->prepare(
            "INSERT INTO MANGA.ARTIGO (TITULO, SUBTITULO, CORPO, AUTOR, AUTOR_ID, DATA, REFERENCIAS) 
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        
        if (!$stmt) {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta: ' . $conexao->error]);
            exit;
        }
        
        $stmt->bind_param("ssssiss", $titulo, $subtitulo, $corpo, $autorNome, $autorId, $data, $referencias);
        
        if ($stmt->execute()) {
            $artigoId = $stmt->insert_id;
            $stmt->close();
            
            http_response_code(201);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Artigo criado com sucesso!',
                'artigoId' => $artigoId,
                'autor' => $autorNome
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao criar artigo: ' . $conexao->error]);
        }
        
        exit;
    }
    
    // ========== EDITAR ARTIGO ==========
    else if ($acao === 'editar') {
        
        $artigoId = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $titulo = isset($_POST['titulo']) ? trim($_POST['titulo']) : '';
        $subtitulo = isset($_POST['subtitulo']) ? trim($_POST['subtitulo']) : '';
        $corpo = isset($_POST['corpo']) ? trim($_POST['corpo']) : '';
        $referencias = isset($_POST['referencias']) ? trim($_POST['referencias']) : '';
        
        // Validações
        if ($artigoId <= 0) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'ID do artigo inválido!']);
            exit;
        }
        
        if (empty($titulo) || empty($corpo)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Título e corpo são obrigatórios!']);
            exit;
        }
        
        // Verificar se o artigo pertence ao usuário logado (ou se é admin)
        $usuarioId = getUsuarioLogadoId();
        $isAdmin = estaAutenticadoComoAdmin();
        
        $stmt = $conexao->prepare("SELECT AUTOR_ID FROM MANGA.ARTIGO WHERE ID = ?");
        $stmt->bind_param("i", $artigoId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Artigo não encontrado!']);
            exit;
        }
        
        $artigo = $resultado->fetch_assoc();
        $stmt->close();
        
        // Somente o autor ou admin podem editar
        if ($artigo['AUTOR_ID'] != $usuarioId && !$isAdmin) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Você não tem permissão para editar este artigo!']);
            exit;
        }
        
        // Atualizar artigo
        $stmt = $conexao->prepare(
            "UPDATE MANGA.ARTIGO SET TITULO = ?, SUBTITULO = ?, CORPO = ?, REFERENCIAS = ? WHERE ID = ?"
        );
        
        if (!$stmt) {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta: ' . $conexao->error]);
            exit;
        }
        
        $stmt->bind_param("ssssi", $titulo, $subtitulo, $corpo, $referencias, $artigoId);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Artigo atualizado com sucesso!'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao atualizar artigo: ' . $conexao->error]);
        }
        
        exit;
    }
    
    // ========== EXCLUIR ARTIGO ==========
    else if ($acao === 'excluir') {
        
        $artigoId = isset($_POST['id']) ? intval($_POST['id']) : 0;
        
        if ($artigoId <= 0) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'ID do artigo inválido!']);
            exit;
        }
        
        // Verificar se o artigo pertence ao usuário logado (ou se é admin)
        $usuarioId = getUsuarioLogadoId();
        $isAdmin = estaAutenticadoComoAdmin();
        
        $stmt = $conexao->prepare("SELECT AUTOR_ID FROM MANGA.ARTIGO WHERE ID = ?");
        $stmt->bind_param("i", $artigoId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Artigo não encontrado!']);
            exit;
        }
        
        $artigo = $resultado->fetch_assoc();
        $stmt->close();
        
        // Somente o autor ou admin podem excluir
        if ($artigo['AUTOR_ID'] != $usuarioId && !$isAdmin) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Você não tem permissão para excluir este artigo!']);
            exit;
        }
        
        // Excluir artigo
        $stmt = $conexao->prepare("DELETE FROM MANGA.ARTIGO WHERE ID = ?");
        $stmt->bind_param("i", $artigoId);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Artigo excluído com sucesso!'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao excluir artigo: ' . $conexao->error]);
        }
        
        exit;
    }
    
    else {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Ação inválida!']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido']);
}

exit;
?>