<?php
// ========== VERIFICAR SESSÃO DO USUÁRIO ==========
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

try {
    // Verificar se há sessão ativa
    $autenticado = estaAutenticado();
    
    if (!$autenticado) {
        echo json_encode([
            'autenticado' => false,
            'logado' => false
        ]);
        exit;
    }
    
    // Buscar ID do usuário
    $usuarioId = getUsuarioLogadoId();
    
    if (!$usuarioId) {
        echo json_encode([
            'autenticado' => false,
            'logado' => false
        ]);
        exit;
    }
    
    // Buscar informações completas do usuário no banco
    $stmt = $conexao->prepare(
        "SELECT 
            ID, 
            NOME, 
            EMAIL, 
            COALESCE(TIPO_USUARIO, 0) as TIPO_USUARIO 
         FROM MANGA.USUARIO 
         WHERE ID = ?"
    );
    
    if (!$stmt) {
        throw new Exception('Erro na preparação da query');
    }
    
    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows === 0) {
        // Usuário não encontrado - sessão inválida
        session_destroy();
        echo json_encode([
            'autenticado' => false,
            'logado' => false
        ]);
        exit;
    }
    
    $usuario = $resultado->fetch_assoc();
    $stmt->close();
    
    // Retornar informações completas (compatível com script.js)
    echo json_encode([
        'autenticado' => true,
        'logado' => true,
        'id' => intval($usuario['ID']),
        'nome' => $usuario['NOME'],
        'email' => $usuario['EMAIL'],
        'tipo' => intval($usuario['TIPO_USUARIO']),
        'tipo_usuario' => intval($usuario['TIPO_USUARIO']),
        'isAdmin' => ($usuario['TIPO_USUARIO'] == 1),
        'isAutor' => ($usuario['TIPO_USUARIO'] == 2 || $usuario['TIPO_USUARIO'] == 1)
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'autenticado' => false,
        'logado' => false,
        'erro' => $e->getMessage()
    ]);
}

exit;
?>