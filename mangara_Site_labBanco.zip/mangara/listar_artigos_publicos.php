<?php
// ========== LISTAR ARTIGOS PÚBLICOS (PARA PÁGINA INICIAL) ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    // Buscar os artigos mais recentes (limite de 6 para a página inicial)
    $limite = isset($_GET['limite']) ? intval($_GET['limite']) : 6;
    
    $stmt = $conexao->prepare(
        "SELECT 
            A.ID,
            A.TITULO,
            A.SUBTITULO,
            A.CORPO,
            A.AUTOR,
            A.DATA,
            (SELECT COUNT(*) FROM MANGA.CURTIDA WHERE ARTIGO_ID = A.ID) as TOTAL_CURTIDAS,
            (SELECT COUNT(*) FROM MANGA.COMENTARIO WHERE ARTIGO_ID = A.ID) as TOTAL_COMENTARIOS
         FROM MANGA.ARTIGO A
         ORDER BY A.DATA DESC, A.ID DESC
         LIMIT ?"
    );
    
    $stmt->bind_param("i", $limite);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    $artigos = [];
    while ($row = $resultado->fetch_assoc()) {
        // Criar resumo do corpo (primeiros 150 caracteres)
        $resumo = substr($row['CORPO'], 0, 150);
        if (strlen($row['CORPO']) > 150) {
            $resumo .= '...';
        }
        
        $artigos[] = [
            'ID' => $row['ID'],
            'TITULO' => $row['TITULO'],
            'SUBTITULO' => $row['SUBTITULO'],
            'RESUMO' => $resumo,
            'AUTOR' => $row['AUTOR'],
            'DATA' => $row['DATA'],
            'TOTAL_CURTIDAS' => intval($row['TOTAL_CURTIDAS']),
            'TOTAL_COMENTARIOS' => intval($row['TOTAL_COMENTARIOS'])
        ];
    }
    
    $stmt->close();
    
    echo json_encode($artigos);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['erro' => $e->getMessage()]);
}

exit;
?>