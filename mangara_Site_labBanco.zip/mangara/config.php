<?php
// ========== CONFIGURAÇÃO DO BANCO DE DADOS ==========

// ============================================================
// CONFIGURAÇÃO DE SESSÃO PERSISTENTE - INÍCIO
// ============================================================
if (session_status() == PHP_SESSION_NONE) {
    // Configurações mais agressivas para manter sessão
    ini_set('session.cookie_lifetime', 86400);      // 24 horas
    ini_set('session.gc_maxlifetime', 86400);       // 24 horas
    ini_set('session.cookie_path', '/');            // Disponível em todo o site
    ini_set('session.cookie_httponly', 1);          // Proteção XSS
    ini_set('session.use_only_cookies', 1);         // Apenas cookies
    ini_set('session.cookie_samesite', 'Lax');      // Proteção CSRF
    
    // Iniciar sessão
    session_start();
    
    // Atualizar timestamp de última atividade
    $_SESSION['LAST_ACTIVITY'] = time();
    
    // Criar timestamp de criação se não existir
    if (!isset($_SESSION['CREATED'])) {
        $_SESSION['CREATED'] = time();
    }
}
// ============================================================
// CONFIGURAÇÃO DE SESSÃO - FIM
// ============================================================

// Dados de conexão
$host = 'localhost:3312';
$usuario = 'root';
$senha = '';
$banco = 'MANGA';

// Criar conexão
$conexao = new mysqli($host, $usuario, $senha, $banco);

// Verificar conexão
if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}

// Definir charset para UTF-8
$conexao->set_charset("utf8");

// ========== CONSTANTES DE TIPOS DE USUÁRIO ==========
define('USUARIO_COMUM', 0);
define('ADMINISTRADOR', 1);
define('AUTOR', 2);

// ========== FUNÇÕES DE AUTENTICAÇÃO ==========

/**
 * Faz login do usuário
 */
function loginUsuario($email, $senha, $tipoEsperado = null) {
    global $conexao;
    
    $sql = "SELECT ID, NOME, EMAIL, TIPO_USUARIO FROM MANGA.USUARIO WHERE EMAIL = ? AND SENHA = ?";
    
    if ($tipoEsperado !== null) {
        $sql .= " AND TIPO_USUARIO = ?";
    }
    
    $stmt = $conexao->prepare($sql);
    
    if (!$stmt) {
        return ['sucesso' => false, 'mensagem' => 'Erro na consulta: ' . $conexao->error];
    }
    
    if ($tipoEsperado !== null) {
        $stmt->bind_param("ssi", $email, $senha, $tipoEsperado);
    } else {
        $stmt->bind_param("ss", $email, $senha);
    }
    
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        
        // LIMPAR SESSÃO ANTIGA
        session_unset();
        
        // CRIAR NOVA SESSÃO COM TODOS OS DADOS
        $_SESSION['isLoggedIn'] = true;
        $_SESSION['userEmail'] = $email;
        $_SESSION['userName'] = $usuario['NOME'];
        $_SESSION['userId'] = $usuario['ID'];
        $_SESSION['usuario_id'] = $usuario['ID'];  // Compatibilidade
        $_SESSION['userType'] = $usuario['TIPO_USUARIO'];
        
        // Definir permissões específicas
        $_SESSION['isAdmin'] = ($usuario['TIPO_USUARIO'] == ADMINISTRADOR);
        $_SESSION['isAutor'] = ($usuario['TIPO_USUARIO'] == AUTOR || $usuario['TIPO_USUARIO'] == ADMINISTRADOR);
        $_SESSION['canManageHerbario'] = ($usuario['TIPO_USUARIO'] == ADMINISTRADOR);
        $_SESSION['canWriteArticles'] = ($usuario['TIPO_USUARIO'] == AUTOR || $usuario['TIPO_USUARIO'] == ADMINISTRADOR);
        
        // Timestamps
        $_SESSION['CREATED'] = time();
        $_SESSION['LAST_ACTIVITY'] = time();
        
        // REGENERAR ID DA SESSÃO (segurança)
        session_regenerate_id(true);
        
        $stmt->close();
        
        $tipoNome = getTipoUsuarioNome($usuario['TIPO_USUARIO']);
        
        return [
            'sucesso' => true,
            'mensagem' => "Login realizado como {$tipoNome}!",
            'usuario' => $usuario,
            'tipoUsuario' => $usuario['TIPO_USUARIO']
        ];
    } else {
        $stmt->close();
        return [
            'sucesso' => false,
            'mensagem' => 'Email, senha ou tipo de acesso incorretos!'
        ];
    }
}

/**
 * Faz login do administrador
 */
function loginAdmin($email, $senha) {
    return loginUsuario($email, $senha, ADMINISTRADOR);
}

/**
 * Faz login do autor
 */
function loginAutor($email, $senha) {
    return loginUsuario($email, $senha, AUTOR);
}

/**
 * Verifica se usuário está autenticado
 */
function estaAutenticado() {
    return isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] === true;
}

/**
 * Verifica se usuário é administrador
 */
function estaAutenticadoComoAdmin() {
    return isset($_SESSION['isAdmin']) && $_SESSION['isAdmin'] === true;
}

/**
 * Verifica se usuário é autor (ou admin)
 */
function estaAutenticadoComoAutor() {
    return isset($_SESSION['isAutor']) && $_SESSION['isAutor'] === true;
}

/**
 * Verifica se usuário pode gerenciar herbário
 */
function podeGerenciarHerbario() {
    return isset($_SESSION['canManageHerbario']) && $_SESSION['canManageHerbario'] === true;
}

/**
 * Verifica se usuário pode escrever artigos
 */
function podeEscreverArtigos() {
    return isset($_SESSION['canWriteArticles']) && $_SESSION['canWriteArticles'] === true;
}

/**
 * Obtém nome do tipo de usuário
 */
function getTipoUsuarioNome($tipo) {
    switch ($tipo) {
        case ADMINISTRADOR:
            return 'Administrador';
        case AUTOR:
            return 'Autor';
        case USUARIO_COMUM:
        default:
            return 'Usuário';
    }
}

/**
 * Obtém ID do usuário logado
 */
function getUsuarioLogadoId() {
    return $_SESSION['userId'] ?? $_SESSION['usuario_id'] ?? null;
}

/**
 * Obtém nome do usuário logado
 */
function getUsuarioLogadoNome() {
    return $_SESSION['userName'] ?? null;
}

/**
 * Obtém tipo do usuário logado
 */
function getUsuarioLogadoTipo() {
    return $_SESSION['userType'] ?? null;
}

/**
 * Faz logout do usuário
 */
function logout() {
    session_unset();
    session_destroy();
    return true;
}

/**
 * Redireciona para página de acesso negado
 */
function acessoNegado($mensagem = "Você não tem permissão para acessar esta página.") {
    http_response_code(403);
    echo "<!DOCTYPE html>
    <html lang='pt-BR'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Acesso Negado - Mangará</title>
        <link rel='stylesheet' href='style.css'>
        <style>
            .acesso-negado-container {
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 2rem;
            }
            .acesso-negado-box {
                background: white;
                padding: 3rem;
                border-radius: 20px;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
                max-width: 500px;
                text-align: center;
            }
            .acesso-negado-icon {
                font-size: 5rem;
                margin-bottom: 1rem;
            }
            .acesso-negado-titulo {
                color: #dc3545;
                font-size: 2rem;
                margin-bottom: 1rem;
            }
            .acesso-negado-mensagem {
                color: #666;
                margin-bottom: 2rem;
                font-size: 1.1rem;
            }
        </style>
    </head>
    <body>
        <div class='acesso-negado-container'>
            <div class='acesso-negado-box'>
                <div class='acesso-negado-icon'>🚫</div>
                <h1 class='acesso-negado-titulo'>Acesso Negado</h1>
                <p class='acesso-negado-mensagem'>{$mensagem}</p>
                <a href='index.html' class='btn btn-primary'>Voltar ao Início</a>
            </div>
        </div>
    </body>
    </html>";
    exit;
}
?>