<?php
require_once 'config.php';

// Verificar se está autenticado como admin
if (!estaAutenticadoComoAdmin()) {
    header("Location: login-adm.html");
    exit;
}
?>
    <!-- SEU HTML CONTINUA AQUI... -->
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administração - Mangará</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- HEADER -->
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="logo.png" alt="Mangará" class="logo-img">
                <span>Mangará</span>
            </div>
            
            <button class="menu-toggle" onclick="toggleMenu()" aria-label="Menu">
                ☰
            </button>

            <nav>
                <ul id="menu">
                    <li><a href="index.html">Início</a></li>
                    <li><a href="herbario.html">Herbário</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="paineladm.php" id="adminLink" class="active">Administração</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- CONTEÚDO PRINCIPAL -->
    <main>
        <div class="admin-header">
            <h1>🛠️ Painel de Administração</h1>
            <button class="btn-logout" onclick="logout()">Sair</button>
        </div>

        <div class="admin-tabs">
            <button class="tab-btn active" onclick="showTab('usuarios')">👥 Gerenciar Usuários</button>
            <button class="tab-btn" onclick="showTab('noticias')">📰 Gerenciar Notícias</button>
            <button class="tab-btn" onclick="showTab('herbario')">🌱 Gerenciar Herbário</button>
        </div>

                <!-- Tab: Gerenciar Usuários -->
        <div id="usuarios-tab" class="tab-content active">
            <div class="admin-section">
                <h2>👥 Gerenciamento de Usuários</h2>
                
                <!-- Filtros em linha -->
                <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                    <select id="filtroTipoUsuario" class="filtro-select" onchange="carregarUsuarios()" style="flex: 0 0 200px;">
                        <option value="">Todos os tipos</option>
                        <option value="0">Usuários Comuns</option>
                        <option value="2">Autores</option>
                        <option value="1">Administradores</option>
                    </select>
                    
                    <input type="text" id="buscaUsuario" class="busca-input" 
                           placeholder="🔍 Buscar usuário..." 
                           onkeyup="filtrarUsuarios()"
                           style="flex: 1; min-width: 250px;">
                </div>

                <!-- Tabela de Usuários -->
                <div style="overflow-x: auto;">
                    <table class="usuarios-table">
                        <thead>
                            <tr>
                                <th style="width: 30%;">Nome</th>
                                <th style="width: 30%;">Email</th>
                                <th style="width: 20%;">Tipo</th>
                                <th style="width: 20%; text-align: center;">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="listaUsuarios">
                            <tr>
                                <td colspan="4" style="text-align: center; color: #666; padding: 2rem;">
                                    Carregando usuários...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tab: Gerenciar Notícias -->
        <div id="noticias-tab" class="tab-content">
            <div class="admin-section">
                <h2>➕ Adicionar Nova Notícia</h2>
                <form class="admin-form" id="formNoticia" enctype="multipart/form-data">
                    
                    <div class="noticias-grid">
                        <!-- Coluna 1: Imagem -->
                        <div class="noticia-imagem-col">
                            <label>Imagem da Notícia:</label>
                            <div class="imagem-preview-box" id="imagemPreviewNoticia" onclick="document.getElementById('inputImagemNoticia').click()">
                                <span class="emoji-display">📰</span>
                                <p class="imagem-hint">Clique para adicionar imagem</p>
                            </div>
                            
                            <div class="imagem-btns">
                                <button type="button" class="btn-icon" onclick="document.getElementById('inputImagemNoticia').click()" title="Upload de Imagem">
                                    🖼️ Escolher
                                </button>
                                <button type="button" class="btn-icon btn-danger" onclick="limparImagemNoticia()" id="btnLimparImagemNoticia" style="display:none;" title="Remover">
                                    🗑️ Remover
                                </button>
                            </div>
                            
                            <input type="file" id="inputImagemNoticia" name="imagem" accept="image/*" style="display:none;" onchange="previewImagemNoticia(event)">
                        </div>
                        
                        <!-- Coluna 2: Campos -->
                        <div class="noticia-campos-col">
                            <div class="form-row-2">
                                <div class="form-group">
                                    <label for="tituloNoticia">Título: *</label>
                                    <input type="text" id="tituloNoticia" name="titulo" placeholder="Título da notícia" required>
                                </div>
                                <div class="form-group">
                                    <label for="dataNoticia">Data: *</label>
                                    <input type="date" id="dataNoticia" name="data" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="conteudoNoticia">Conteúdo: *</label>
                                <textarea id="conteudoNoticia" name="conteudo" rows="8" placeholder="Escreva o conteúdo..." required></textarea>
                            </div>
                            
                            <button type="submit" class="btn-primary btn-block">📤 Publicar Notícia</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Lista de Notícias -->
            <div class="admin-section" style="margin-top: 2rem;">
                <h2>📋 Notícias Publicadas</h2>
                <div id="listaNoticias" class="admin-list">
                    <p style="text-align: center; color: #666;">Carregando notícias...</p>
                </div>
            </div>
        </div>

        <!-- Tab: Gerenciar Herbário -->
        <div id="herbario-tab" class="tab-content">
            <div class="admin-section">
                <h2>🌱 Adicionar Nova Planta</h2>
                <form class="admin-form" id="formPlanta" enctype="multipart/form-data">
                    
                    <!-- Grid: Imagem + Campos -->
                    <div class="herbario-grid">
                        
                        <!-- Coluna 1: Imagem/Emoji -->
                        <div class="herbario-imagem-col">
                            <label>Imagem/Ícone da Planta:</label>
                            <div class="imagem-preview-box" id="imagemPreview" onclick="document.getElementById('inputImagem').click()">
                                <span class="emoji-display">🌿</span>
                                <p class="imagem-hint">Clique para adicionar</p>
                            </div>
                            
                            <div class="imagem-btns">
                                <button type="button" class="btn-icon" onclick="document.getElementById('inputImagem').click()" title="Upload de Imagem">
                                    🖼️
                                </button>
                                <button type="button" class="btn-icon" onclick="abrirSeletorEmoji()" title="Escolher Emoji">
                                    😊
                                </button>
                                <button type="button" class="btn-icon btn-danger" onclick="limparImagem()" id="btnLimparImagem" style="display:none;" title="Remover">
                                    🗑️
                                </button>
                            </div>
                            
                            <input type="file" id="inputImagem" accept="image/*" style="display:none;" onchange="previewImagem(event)">
                            <input type="hidden" id="tipoImagem" name="tipoImagem" value="emoji">
                            <input type="hidden" id="valorImagem" name="valorImagem" value="🌿">
                        </div>
                        
                        <!-- Coluna 2: Campos do Formulário -->
                        <div class="herbario-campos-col">
                            
                            <div class="form-row-2">
                                <div class="form-group">
                                    <label for="nomeComum">Nome Comum: *</label>
                                    <input type="text" id="nomeComum" name="nomeComum" placeholder="Ex: Alface Crespa" required>
                                </div>
                                <div class="form-group">
                                    <label for="nomeCientifico">Nome Científico: *</label>
                                    <input type="text" id="nomeCientifico" name="nomeCientifico" placeholder="Ex: Lactuca sativa" required>
                                </div>
                            </div>
                            
                            <div class="form-row-2">
                                <div class="form-group">
                                    <label for="apelido">Apelido:</label>
                                    <input type="text" id="apelido" name="apelido" placeholder="Ex: Pezinho de Alface">
                                </div>
                                <div class="form-group">
                                    <label for="familia">Família:</label>
                                    <input type="text" id="familia" name="familia" placeholder="Ex: Asteraceae">
                                </div>
                            </div>
                            
                            <div class="form-row-3">
                                <div class="form-group">
                                    <label for="tipo">Tipo:</label>
                                    <select id="tipo" name="tipo">
                                        <option value="">Selecione...</option>
                                        <option value="1">Hortaliça</option>
                                        <option value="2">Flor</option>
                                        <option value="3">Árvore</option>
                                        <option value="4">Arbusto</option>
                                        <option value="5">Suculenta</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="utilidade">Utilidade:</label>
                                    <select id="utilidade" name="utilidade">
                                        <option value="">Selecione...</option>
                                        <option value="1">Alimentação</option>
                                        <option value="2">Medicinal</option>
                                        <option value="3">Ornamental</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="solo">Solo:</label>
                                    <select id="solo" name="solo">
                                        <option value="">Selecione...</option>
                                        <option value="1">Arenoso</option>
                                        <option value="2">Argiloso</option>
                                        <option value="3">Humoso</option>
                                    </select>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn-primary btn-block">✅ Cadastrar Planta</button>
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- Modal Seletor de Emoji -->
    <div id="modalEmoji" class="modal-emoji" style="display:none;" onclick="if(event.target === this) fecharSeletorEmoji()">
        <div class="modal-emoji-content">
            <div class="modal-emoji-header">
                <h3>😊 Escolher Emoji</h3>
                <button type="button" class="modal-close" onclick="fecharSeletorEmoji()">✕</button>
            </div>
            <div class="modal-emoji-body">
                <div class="emoji-cats">
                    <button type="button" class="emoji-cat-btn active" onclick="filtrarEmojis('plantas')">🌿</button>
                    <button type="button" class="emoji-cat-btn" onclick="filtrarEmojis('flores')">🌸</button>
                    <button type="button" class="emoji-cat-btn" onclick="filtrarEmojis('frutas')">🍎</button>
                    <button type="button" class="emoji-cat-btn" onclick="filtrarEmojis('vegetais')">🥬</button>
                </div>
                <div class="emoji-grid" id="emojiGrid"></div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <div class="footer-info">
                <h3>Mangará Núcleo Agroecológico</h3>
                <p>Projeto do Instituto Federal de São Paulo - Campus São Miguel Paulista</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Mangará - Todos os direitos reservados</p>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="script.js"></script>
</body>
</html>