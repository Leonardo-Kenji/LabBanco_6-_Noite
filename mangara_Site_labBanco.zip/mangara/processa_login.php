<?php
// ========== PROCESSA LOGIN ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verifica se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Recebe os dados do formulário
    $tipo_login = isset($_POST['tipo']) ? $_POST['tipo'] : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $senha = isset($_POST['senha']) ? $_POST['senha'] : '';
    $redirect_url = isset($_POST['redirect']) ? $_POST['redirect'] : '';
    
    // Validar campos vazios
    if (empty($email) || empty($senha)) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Email e senha são obrigatórios!']);
        exit;
    }
    
    // Fazer login conforme o tipo
    if ($tipo_login === 'usuario') {
        // Login de usuário comum (qualquer tipo pode fazer login básico)
        $resultado = loginUsuario($email, $senha);
        
        // Se há URL de redirecionamento, usar ela, senão usar index.html
        if (!empty($redirect_url)) {
            $redirect = $redirect_url;
        } else {
            $redirect = 'index.html';
        }
        
    } elseif ($tipo_login === 'admin') {
        // Login específico de administrador
        $resultado = loginAdmin($email, $senha);
        $redirect = 'paineladm.php';
        
    } elseif ($tipo_login === 'autor') {
        // Login específico de autor
        $resultado = loginAutor($email, $senha);
        $redirect = 'painel-autor.php';
        
    } else {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Tipo de login inválido!']);
        exit;
    }
    
    // Retornar resultado em JSON
    if ($resultado['sucesso']) {
        
        // ============================================================
        // 🔥 PARTE NOVA/MODIFICADA - ADICIONAR ESTAS LINHAS AQUI 🔥
        // ============================================================
        
        // Garantir compatibilidade com verificação de sessão
        $_SESSION['usuario_id'] = $resultado['usuario']['ID'];
        
        // Garantir que todos os dados estão setados corretamente
        $_SESSION['isLoggedIn'] = true;
        $_SESSION['userId'] = $resultado['usuario']['ID'];
        $_SESSION['userName'] = $resultado['usuario']['NOME'];
        $_SESSION['userEmail'] = $resultado['usuario']['EMAIL'];
        $_SESSION['userType'] = $resultado['tipoUsuario'];
        
        // ============================================================
        // FIM DA PARTE NOVA
        // ============================================================
        
        http_response_code(200);
        echo json_encode([
            'sucesso' => true,
            'mensagem' => $resultado['mensagem'],
            'redirect' => $redirect,
            'tipoUsuario' => $resultado['tipoUsuario'],
            'nome' => $resultado['usuario']['NOME'] ?? '',
            'email' => $resultado['usuario']['EMAIL'] ?? '',
            'id' => $resultado['usuario']['ID'] ?? 0
        ]);
    } else {
        http_response_code(401);
        echo json_encode([
            'sucesso' => false,
            'mensagem' => $resultado['mensagem']
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido']);
}

exit;
?>