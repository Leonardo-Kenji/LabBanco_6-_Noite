<?php
require_once 'config.php';

// Verificar se está autenticado como autor
if (!estaAutenticadoComoAutor()) {
    header("Location: login-autor.html");
    exit;
}

// Obter informações do autor
$autorNome = getUsuarioLogadoNome();
$autorId = getUsuarioLogadoId();
$isAdmin = estaAutenticadoComoAdmin();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Autor - Mangará</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Estilos específicos do painel do autor */
        .artigo-grid {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 2rem;
            align-items: start;
        }

        @media (max-width: 968px) {
            .artigo-grid {
                grid-template-columns: 1fr;
            }
        }

        .artigo-preview-col {
            position: sticky;
            top: 2rem;
        }

        .artigo-preview-box {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px dashed #c8e357;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            min-height: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .artigo-preview-box:hover {
            border-color: #1a4d2e;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(26, 77, 46, 0.1);
        }

        .preview-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .preview-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: #1a4d2e;
            margin-bottom: 0.5rem;
        }

        .preview-subtitle {
            color: #666;
            font-size: 0.9rem;
        }

        .preview-stats {
            display: flex;
            gap: 1rem;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid #ddd;
            width: 100%;
            justify-content: center;
        }

        .preview-stat {
            text-align: center;
        }

        .preview-stat-number {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1a4d2e;
            display: block;
        }

        .preview-stat-label {
            font-size: 0.8rem;
            color: #666;
            display: block;
        }

        .artigo-campos-col {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .editor-toolbar {
            background: #f8f9fa;
            padding: 0.5rem;
            border-radius: 8px;
            margin-bottom: 0.5rem;
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        .editor-btn {
            padding: 0.4rem 0.8rem;
            border: 1px solid #ddd;
            background: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s ease;
        }

        .editor-btn:hover {
            background: #c8e357;
            border-color: #1a4d2e;
        }

        .char-counter {
            text-align: right;
            color: #666;
            font-size: 0.85rem;
            margin-top: 0.3rem;
        }

        .artigo-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border-left: 4px solid #c8e357;
            transition: all 0.3s ease;
        }

        .artigo-card:hover {
            box-shadow: 0 4px 16px rgba(0,0,0,0.1);
            transform: translateX(5px);
        }

        .artigo-card-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 1rem;
        }

        .artigo-card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a4d2e;
            margin-bottom: 0.5rem;
        }

        .artigo-card-subtitle {
            color: #666;
            font-style: italic;
            font-size: 0.95rem;
        }

        .artigo-card-meta {
            display: flex;
            gap: 1.5rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
            font-size: 0.9rem;
            color: #999;
        }

        .artigo-card-actions {
            display: flex;
            gap: 0.5rem;
        }

        .badge-autor {
            background: linear-gradient(135deg, #2d6b3e 0%, #1a4d2e 100%);
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: #999;
        }

        .empty-state-icon {
            font-size: 5rem;
            margin-bottom: 1rem;
            opacity: 0.3;
        }

        .empty-state-title {
            font-size: 1.5rem;
            color: #666;
            margin-bottom: 0.5rem;
        }

        .empty-state-text {
            color: #999;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="logo.png" alt="Mangará" class="logo-img">
                <span>Mangará</span>
            </div>
            
            <button class="menu-toggle" onclick="toggleMenu()" aria-label="Menu">
                ☰
            </button>

            <nav>
                <ul id="menu">
                    <li><a href="index.html">Início</a></li>
                    <li><a href="herbario.html">Herbário</a></li>
                    <li><a href="login.html">Login</a></li>
                    <?php if ($isAdmin): ?>
                    <li><a href="paineladm.php">Administração</a></li>
                    <?php endif; ?>
                    <li><a href="painel-autor.php" class="active">Painel do Autor</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- CONTEÚDO PRINCIPAL -->
    <main>
        <div class="admin-header" style="background: linear-gradient(135deg, #2d6b3e 0%, #1a4d2e 100%);">
            <div>
                <h1>✍️ Painel do Autor</h1>
                <p style="margin: 0.5rem 0 0 0; opacity: 0.9;">Bem-vindo(a), <?php echo htmlspecialchars($autorNome); ?>!</p>
            </div>
            <button class="btn-logout" onclick="logout()">Sair</button>
        </div>

        <div class="admin-tabs">
            <button class="tab-btn active" onclick="showTab('criar')">✏️ Criar Artigo</button>
            <button class="tab-btn" onclick="showTab('meus')">📚 Meus Artigos</button>
            <?php if ($isAdmin): ?>
            <button class="tab-btn" onclick="showTab('todos')">🌍 Todos os Artigos</button>
            <?php endif; ?>
        </div>

        <!-- Tab: Criar Artigo -->
        <div id="criar-tab" class="tab-content active">
            <div class="admin-section">
                <h2>✏️ Criar Novo Artigo</h2>
                <form class="admin-form" id="formCriarArtigo">
                    
                    <!-- Grid: Preview + Campos -->
                    <div class="artigo-grid">
                        
                        <!-- Coluna 1: Preview -->
                        <div class="artigo-preview-col">
                            <div class="artigo-preview-box">
                                <div class="preview-icon">📝</div>
                                <div class="preview-title">Seu Artigo</div>
                                <div class="preview-subtitle">Preencha os campos ao lado para criar seu artigo</div>
                                
                                <div class="preview-stats">
                                    <div class="preview-stat">
                                        <span class="preview-stat-number" id="previewTituloCount">0</span>
                                        <span class="preview-stat-label">Título</span>
                                    </div>
                                    <div class="preview-stat">
                                        <span class="preview-stat-number" id="previewCorpoCount">0</span>
                                        <span class="preview-stat-label">Palavras</span>
                                    </div>
                                </div>
                            </div>

                            <div class="form-info" style="margin-top: 1rem;">
                                <p><strong>👤 Autor:</strong> <?php echo htmlspecialchars($autorNome); ?></p>
                                <p style="color: #666; font-size: 0.85rem; margin-top: 0.5rem;">
                                    Seu nome será automaticamente registrado como autor deste artigo.
                                </p>
                            </div>
                        </div>
                        
                        <!-- Coluna 2: Campos do Formulário -->
                        <div class="artigo-campos-col">
                            
                            <div class="form-group">
                                <label for="titulo">Título do Artigo: *</label>
                                <input type="text" id="titulo" name="titulo" placeholder="Digite um título impactante..." required maxlength="200">
                                <div class="char-counter">
                                    <span id="tituloCounter">0</span> / 200 caracteres
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="subtitulo">Subtítulo (opcional):</label>
                                <input type="text" id="subtitulo" name="subtitulo" placeholder="Um resumo breve que complemente o título" maxlength="300">
                                <div class="char-counter">
                                    <span id="subtituloCounter">0</span> / 300 caracteres
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="corpo">Corpo do Artigo: *</label>
                                <small style="color: #666; display: block; margin-bottom: 0.5rem;">
                                    💡 Dica: Use parágrafos curtos e objetivos para melhor leitura
                                </small>
                                <textarea id="corpo" name="corpo" rows="15" placeholder="Escreva o conteúdo do seu artigo aqui...

Use quebras de linha para criar parágrafos.

Seja claro, objetivo e informativo." required></textarea>
                                <div class="char-counter">
                                    <span id="corpoCounter">0</span> caracteres | <span id="palavrasCounter">0</span> palavras
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="referencias">Referências (opcional):</label>
                                <small style="color: #666; display: block; margin-bottom: 0.5rem;">
                                    📚 Liste suas fontes, links e referências bibliográficas
                                </small>
                                <textarea id="referencias" name="referencias" rows="4" placeholder="Exemplo:
- Silva, J. (2024). Título do Livro. Editora.
- https://exemplo.com/artigo-referencia
- Autor, A. (2023). Nome da Publicação."></textarea>
                            </div>

                            <div id="mensagemCriar" style="display: none;"></div>

                            <button type="submit" class="btn-primary btn-block">📤 Publicar Artigo</button>
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tab: Meus Artigos -->
        <div id="meus-tab" class="tab-content">
            <div class="admin-section">
                <h2>📚 Meus Artigos Publicados</h2>
                <div id="meusArtigosLista">
                    <div class="empty-state">
                        <div class="empty-state-icon">📝</div>
                        <div class="empty-state-title">Carregando seus artigos...</div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($isAdmin): ?>
        <!-- Tab: Todos os Artigos (apenas admin) -->
        <div id="todos-tab" class="tab-content">
            <div class="admin-section">
                <h2>🌍 Todos os Artigos do Sistema</h2>
                <p style="color: #666; margin-bottom: 1.5rem;">
                    Como administrador, você pode visualizar e gerenciar todos os artigos publicados no sistema.
                </p>
                <div id="todosArtigosLista">
                    <div class="empty-state">
                        <div class="empty-state-icon">🌍</div>
                        <div class="empty-state-title">Carregando artigos...</div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <div class="footer-info">
                <h3>Mangará Núcleo Agroecológico</h3>
                <p>Projeto do Instituto Federal de São Paulo - Campus São Miguel Paulista</p>
                <p>Desenvolvido por estudantes do campus</p>
            </div>
            
            <div class="footer-contato">
                <h4>Contato</h4>
                <p>📍 Rua Tenente Miguel Délia 105, São Paulo</p>
                <p>📧 forms.gle/cE8VbSG3oMtz3gyr6</p>
                <p>📱 Instagram: @horteires_ifsp</p>
            </div>
            
            <div class="footer-social">
                <h4>Redes Sociais</h4>
                <div class="social-links">
                    <a href="https://www.instagram.com/horteires_ifsp/" target="_blank">Instagram</a>
                    <a href="#" target="_blank">Facebook</a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Mangará - Todos os direitos reservados</p>
        </div>
    </footer>

    <!-- CHATBOT IA -->
    <div class="chatbot-button" onclick="abrirChatbot()" title="Assistente Virtual">
        <div class="chatbot-icon">🤖</div>
    </div>

    <script src="script.js"></script>
    <script>
        // ========== CONTADORES DE CARACTERES ==========
        
        const titulo = document.getElementById('titulo');
        const subtitulo = document.getElementById('subtitulo');
        const corpo = document.getElementById('corpo');
        
        titulo.addEventListener('input', () => {
            const count = titulo.value.length;
            document.getElementById('tituloCounter').textContent = count;
            document.getElementById('previewTituloCount').textContent = count > 0 ? '✓' : '0';
        });
        
        subtitulo.addEventListener('input', () => {
            const count = subtitulo.value.length;
            document.getElementById('subtituloCounter').textContent = count;
        });
        
        corpo.addEventListener('input', () => {
            const text = corpo.value;
            const charCount = text.length;
            const wordCount = text.trim().split(/\s+/).filter(word => word.length > 0).length;
            
            document.getElementById('corpoCounter').textContent = charCount;
            document.getElementById('palavrasCounter').textContent = wordCount;
            document.getElementById('previewCorpoCount').textContent = wordCount;
        });

        // ========== CRIAR ARTIGO ==========
        
        document.getElementById('formCriarArtigo').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('acao', 'criar');
            
            const btnSubmit = e.target.querySelector('button[type="submit"]');
            const originalText = btnSubmit.innerHTML;
            btnSubmit.disabled = true;
            btnSubmit.innerHTML = '⏳ Publicando...';
            
            try {
                const response = await fetch('processa_artigo.php', {
                    method: 'POST',
                    body: new URLSearchParams(formData)
                });
                
                const resultado = await response.json();
                const mensagem = document.getElementById('mensagemCriar');
                
                if (resultado.sucesso) {
                    mensagem.className = 'success-message';
                    mensagem.innerHTML = '✅ ' + resultado.mensagem;
                    mensagem.style.display = 'block';
                    e.target.reset();
                    
                    // Resetar contadores
                    document.getElementById('tituloCounter').textContent = '0';
                    document.getElementById('subtituloCounter').textContent = '0';
                    document.getElementById('corpoCounter').textContent = '0';
                    document.getElementById('palavrasCounter').textContent = '0';
                    document.getElementById('previewTituloCount').textContent = '0';
                    document.getElementById('previewCorpoCount').textContent = '0';
                    
                    // Ir para aba "Meus Artigos"
                    setTimeout(() => {
                        showTab('meus');
                    }, 2000);
                } else {
                    mensagem.className = 'error-message';
                    mensagem.innerHTML = '❌ ' + resultado.mensagem;
                    mensagem.style.display = 'block';
                }
                
                setTimeout(() => {
                    mensagem.style.display = 'none';
                }, 5000);
                
            } catch (erro) {
                console.error('Erro:', erro);
                const mensagem = document.getElementById('mensagemCriar');
                mensagem.className = 'error-message';
                mensagem.innerHTML = '❌ Erro ao publicar artigo!';
                mensagem.style.display = 'block';
            } finally {
                btnSubmit.disabled = false;
                btnSubmit.innerHTML = originalText;
            }
        });

        // ========== CARREGAR MEUS ARTIGOS ==========
        
        async function carregarMeusArtigos() {
            const lista = document.getElementById('meusArtigosLista');
            lista.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">⏳</div>
                    <div class="empty-state-title">Carregando seus artigos...</div>
                </div>
            `;
            
            try {
                const response = await fetch('listar_artigos.php?meus=1');
                const artigos = await response.json();
                
                if (artigos.length === 0) {
                    lista.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-state-icon">📝</div>
                            <div class="empty-state-title">Nenhum artigo publicado ainda</div>
                            <div class="empty-state-text">Comece criando seu primeiro artigo na aba "Criar Artigo"</div>
                            <button class="btn-primary" onclick="showTab('criar')">✏️ Criar Meu Primeiro Artigo</button>
                        </div>
                    `;
                    return;
                }
                
                lista.innerHTML = '';
                artigos.forEach(artigo => {
                    const card = criarCardArtigo(artigo, false);
                    lista.appendChild(card);
                });
                
            } catch (erro) {
                console.error('Erro:', erro);
                lista.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">❌</div>
                        <div class="empty-state-title">Erro ao carregar artigos</div>
                        <div class="empty-state-text">Tente recarregar a página</div>
                    </div>
                `;
            }
        }

        <?php if ($isAdmin): ?>
        // ========== CARREGAR TODOS OS ARTIGOS (ADMIN) ==========
        
        async function carregarTodosArtigos() {
            const lista = document.getElementById('todosArtigosLista');
            lista.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">⏳</div>
                    <div class="empty-state-title">Carregando artigos...</div>
                </div>
            `;
            
            try {
                const response = await fetch('listar_artigos.php?todos=1');
                const artigos = await response.json();
                
                if (artigos.length === 0) {
                    lista.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-state-icon">🌍</div>
                            <div class="empty-state-title">Nenhum artigo publicado ainda</div>
                            <div class="empty-state-text">Aguardando publicações de autores</div>
                        </div>
                    `;
                    return;
                }
                
                lista.innerHTML = '';
                artigos.forEach(artigo => {
                    const card = criarCardArtigo(artigo, true);
                    lista.appendChild(card);
                });
                
            } catch (erro) {
                console.error('Erro:', erro);
                lista.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">❌</div>
                        <div class="empty-state-title">Erro ao carregar artigos</div>
                        <div class="empty-state-text">Tente recarregar a página</div>
                    </div>
                `;
            }
        }
        <?php endif; ?>

        // ========== CRIAR CARD DE ARTIGO ==========
        
        function criarCardArtigo(artigo, mostrarAutor) {
            const card = document.createElement('div');
            card.className = 'artigo-card';
            
            const dataFormatada = formatarData(artigo.DATA);
            
            card.innerHTML = `
                <div class="artigo-card-header">
                    <div style="flex: 1;">
                        <div class="artigo-card-title">${escapeHtml(artigo.TITULO)}</div>
                        ${artigo.SUBTITULO ? `<div class="artigo-card-subtitle">${escapeHtml(artigo.SUBTITULO)}</div>` : ''}
                    </div>
                    <div class="artigo-card-actions">
                        <button class="btn-edit" onclick="editarArtigo(${artigo.ID})" title="Editar">✏️</button>
                        <button class="btn-delete" onclick="excluirArtigo(${artigo.ID})" title="Excluir">🗑️</button>
                    </div>
                </div>
                <div class="artigo-card-meta">
                    ${mostrarAutor ? `<span>👤 ${escapeHtml(artigo.AUTOR)}</span>` : ''}
                    <span>📅 ${dataFormatada}</span>
                    <span>📝 Artigo</span>
                </div>
            `;
            
            return card;
        }

        // ========== FUNÇÕES AUXILIARES ==========
        
        function editarArtigo(id) {
            alert('🚧 Função de edição em desenvolvimento.\n\nID do artigo: ' + id);
        }

        async function excluirArtigo(id) {
            if (!confirm('⚠️ Tem certeza que deseja excluir este artigo?\n\nEsta ação não pode ser desfeita.')) {
                return;
            }
            
            try {
                const response = await fetch('processa_artigo.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `acao=excluir&id=${id}`
                });
                
                const resultado = await response.json();
                
                if (resultado.sucesso) {
                    mostrarMensagem('success', '✅ ' + resultado.mensagem);
                    carregarMeusArtigos();
                    <?php if ($isAdmin): ?>
                    carregarTodosArtigos();
                    <?php endif; ?>
                } else {
                    mostrarMensagem('error', '❌ ' + resultado.mensagem);
                }
                
            } catch (erro) {
                console.error('Erro:', erro);
                mostrarMensagem('error', '❌ Erro ao excluir artigo!');
            }
        }

        function formatarData(dataString) {
            const data = new Date(dataString + 'T00:00:00');
            return data.toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: 'short',
                year: 'numeric'
            });
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // ========== TROCAR ABAS ==========
        
        function showTab(tabName) {
            const allTabs = document.querySelectorAll('.tab-content');
            const allButtons = document.querySelectorAll('.tab-btn');
            
            allTabs.forEach(tab => tab.classList.remove('active'));
            allButtons.forEach(btn => btn.classList.remove('active'));
            
            const selectedTab = document.getElementById(tabName + '-tab');
            if (selectedTab) {
                selectedTab.classList.add('active');
            }
            
            // Ativar botão correto
            const buttons = document.querySelectorAll('.tab-btn');
            buttons.forEach((btn, index) => {
                if ((tabName === 'criar' && index === 0) ||
                    (tabName === 'meus' && index === 1) ||
                    (tabName === 'todos' && index === 2)) {
                    btn.classList.add('active');
                }
            });
            
            // Carregar dados conforme a aba
            if (tabName === 'meus') {
                carregarMeusArtigos();
            }
            <?php if ($isAdmin): ?>
            else if (tabName === 'todos') {
                carregarTodosArtigos();
            }
            <?php endif; ?>
        }

        // ========== INICIALIZAÇÃO ==========
        
        window.addEventListener('DOMContentLoaded', () => {
            console.log('✅ Painel do Autor carregado');
        });
    </script>
</body>
</html>
