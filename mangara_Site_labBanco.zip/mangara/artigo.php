<?php
require_once 'config.php';

// Obter ID do artigo da URL
$artigoId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($artigoId <= 0) {
    header("Location: index.html");
    exit;
}

// Buscar dados do artigo
$stmt = $conexao->prepare(
    "SELECT A.*, U.NOME as AUTOR_NOME 
     FROM MANGA.ARTIGO A
     LEFT JOIN MANGA.USUARIO U ON U.ID = A.AUTOR_ID
     WHERE A.ID = ?"
);
$stmt->bind_param("i", $artigoId);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    header("Location: index.html");
    exit;
}

$artigo = $resultado->fetch_assoc();
$stmt->close();

// Verificar se usuário está autenticado
$usuarioLogado = estaAutenticado();
$usuarioId = $usuarioLogado ? getUsuarioLogadoId() : null;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($artigo['TITULO']); ?> - Mangará</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- HEADER -->
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="logo.png" alt="Mangará" class="logo-img">
                <span>Mangará</span>
            </div>
            
            <button class="menu-toggle" onclick="toggleMenu()" aria-label="Menu">
                ☰
            </button>

            <nav>
                <ul id="menu">
                    <li><a href="index.html">Início</a></li>
                    <li><a href="herbario.html">Herbário</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="paineladm.php" id="adminLink" style="display: none;">Administração</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- CONTEÚDO PRINCIPAL -->
    <main>
        <div class="container">
            <div class="artigo-container">
                <!-- Breadcrumb -->
                <div class="breadcrumb">
                    <a href="index.html">Início</a> 
                    <span>→</span> 
                    <span>Artigos</span>
                    <span>→</span>
                    <span><?php echo htmlspecialchars($artigo['TITULO']); ?></span>
                </div>

                <!-- Cabeçalho do Artigo -->
                <div class="artigo-header">
                    <h1 class="artigo-titulo"><?php echo htmlspecialchars($artigo['TITULO']); ?></h1>
                    
                    <?php if (!empty($artigo['SUBTITULO'])): ?>
                        <p class="artigo-subtitulo"><?php echo htmlspecialchars($artigo['SUBTITULO']); ?></p>
                    <?php endif; ?>
                    
                    <div class="artigo-meta">
                        <div class="artigo-meta-item">
                            <span>✍️</span>
                            <span>Por <span class="artigo-autor"><?php echo htmlspecialchars($artigo['AUTOR']); ?></span></span>
                        </div>
                        <div class="artigo-meta-item">
                            <span>📅</span>
                            <span><?php echo date('d/m/Y', strtotime($artigo['DATA'])); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Corpo do Artigo -->
                <div class="artigo-corpo">
                    <?php echo nl2br(htmlspecialchars($artigo['CORPO'])); ?>
                </div>

                <!-- Referências (se houver) -->
                <?php if (!empty($artigo['REFERENCIAS'])): ?>
                    <div class="artigo-referencias">
                        <h3>📚 Referências</h3>
                        <p><?php echo nl2br(htmlspecialchars($artigo['REFERENCIAS'])); ?></p>
                    </div>
                <?php endif; ?>

                <!-- Sistema de Curtidas (sempre visível) -->
                <div id="curtidas-container" style="min-height: 80px;"></div>

                <!-- Sistema de Comentários (sempre visível) -->
                <div id="comentarios-container" style="min-height: 200px;"></div>

                <!-- Voltar -->
                <div class="artigo-voltar">
                    <a href="index.html" class="btn btn-secondary">← Voltar para Início</a>
                </div>
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <div class="footer-info">
                <h3>Mangará Núcleo Agroecológico</h3>
                <p>Projeto do Instituto Federal de São Paulo - Campus São Miguel Paulista</p>
                <p>Desenvolvido por estudantes do campus 🎓</p>
            </div>
            
            <div class="footer-contato">
                <h4>Contato</h4>
                <p>📍 Rua Tenente Miguel Délia 105, São Paulo</p>
                <p>📧 forms.gle/cE8VbSG3oMtz3gyr6</p>
                <p>📱 Instagram: @horteires_ifsp</p>
            </div>
            
            <div class="footer-social">
                <h4>Redes Sociais</h4>
                <div class="social-links">
                    <a href="https://www.instagram.com/horteires_ifsp/" target="_blank">Instagram</a>
                    <a href="#" target="_blank">Facebook</a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Mangará - Todos os direitos reservados</p>
        </div>
    </footer>

    <!-- CHATBOT IA -->
    <div class="chatbot-button" onclick="abrirChatbot()" title="Assistente Virtual">
        <div class="chatbot-icon">🤖</div>
    </div>

    <!-- SCRIPTS -->
    <script src="script.js"></script>
    
    <script>
        console.log('🔧 Script de inicialização carregado');
        
        // Dados do usuário
        const usuarioLogado = <?php echo $usuarioLogado ? 'true' : 'false'; ?>;
        const usuarioId = <?php echo $usuarioId ?? 'null'; ?>;
        const artigoId = <?php echo $artigoId; ?>;
        const redirectUrl = 'login.html?redirect=' + encodeURIComponent('artigo.php?id=<?php echo $artigoId; ?>');
        
        console.log('👤 Usuário logado:', usuarioLogado);
        console.log('🆔 ID do artigo:', artigoId);
        
        // Função para inicializar interações
        function inicializarInteracoes() {
            console.log('🚀 Inicializando interações do artigo ID:', artigoId);
            
            // Verificar se a classe existe
            if (typeof InteracoesArtigo === 'undefined') {
                console.error('❌ Classe InteracoesArtigo não encontrada!');
                return;
            }
            
            try {
                // Criar instância global
                window.interacoes = new InteracoesArtigo(artigoId);
                
                // Passar informações de autenticação
                window.interacoes.usuarioLogado = usuarioLogado;
                window.interacoes.usuarioLogadoId = usuarioId;
                window.interacoes.redirectUrl = redirectUrl;
                
                console.log('✅ Instância criada:', window.interacoes);
                
                // Inicializar curtidas e comentários (sempre, logado ou não)
                window.interacoes.inicializarCurtidas('curtidas-container');
                window.interacoes.inicializarComentarios('comentarios-container');
                
                console.log('✅ Interações inicializadas com sucesso!');
            } catch (erro) {
                console.error('❌ Erro ao inicializar:', erro);
                console.error('Stack:', erro.stack);
            }
        }
        
        // Verificar se DOM já está pronto ou aguardar
        if (document.readyState === 'loading') {
            console.log('⏳ Aguardando DOM...');
            document.addEventListener('DOMContentLoaded', inicializarInteracoes);
        } else {
            console.log('✅ DOM já pronto, executando...');
            inicializarInteracoes();
        }
        
        // Override da função verificarAutorComentario
        if (typeof InteracoesArtigo !== 'undefined') {
            InteracoesArtigo.prototype.verificarAutorComentario = function(usuarioIdComentario) {
                return this.usuarioLogadoId === usuarioIdComentario;
            };
        }
    </script>

    <style>
        /* Estilos específicos da página de artigo */
        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 2rem;
            font-size: 0.9rem;
            color: #666;
            flex-wrap: wrap;
        }

        .breadcrumb a {
            color: #1a4d2e;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb a:hover {
            color: #c8e357;
        }

        .artigo-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }

        .artigo-header {
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 2px solid #eee;
        }

        .artigo-titulo {
            color: #1a4d2e;
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 1rem;
            line-height: 1.2;
        }

        .artigo-subtitulo {
            color: #666;
            font-size: 1.2rem;
            font-weight: 400;
            margin-bottom: 1.5rem;
            line-height: 1.4;
        }

        .artigo-meta {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
            color: #999;
            font-size: 0.95rem;
        }

        .artigo-meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .artigo-autor {
            font-weight: 700;
            color: #1a4d2e;
        }

        .artigo-corpo {
            margin: 2rem 0;
            font-size: 1.05rem;
            line-height: 1.8;
            color: #333;
        }

        .artigo-corpo p {
            margin-bottom: 1.5rem;
        }

        .artigo-referencias {
            margin-top: 3rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-left: 4px solid #c8e357;
            border-radius: 8px;
        }

        .artigo-referencias h3 {
            color: #1a4d2e;
            margin-bottom: 1rem;
        }

        .artigo-referencias p {
            color: #666;
            font-size: 0.95rem;
            line-height: 1.6;
            white-space: pre-wrap;
        }

        .artigo-voltar {
            margin-top: 3rem;
            padding-top: 2rem;
            border-top: 2px solid #eee;
            text-align: center;
        }

        @media (max-width: 768px) {
            .artigo-container {
                padding: 1.5rem;
                margin: 1rem;
            }

            .artigo-titulo {
                font-size: 1.8rem;
            }

            .artigo-subtitulo {
                font-size: 1rem;
            }

            .artigo-corpo {
                font-size: 1rem;
            }
        }
    </style>
</body>
</html>