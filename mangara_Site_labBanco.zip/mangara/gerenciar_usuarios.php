<?php
// ========== GERENCIAR USUÁRIOS ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se está autenticado como admin
if (!estaAutenticadoComoAdmin()) {
    http_response_code(403);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Acesso negado!']);
    exit;
}

// Verifica se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $acao = isset($_POST['acao']) ? $_POST['acao'] : '';
    
    // ========== PROMOVER USUÁRIO A AUTOR ==========
    if ($acao === 'promover_autor') {
        
        $usuarioId = isset($_POST['usuario_id']) ? intval($_POST['usuario_id']) : 0;
        
        if ($usuarioId <= 0) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'ID de usuário inválido!']);
            exit;
        }
        
        // Verificar se o usuário existe e não é admin
        $stmt = $conexao->prepare("SELECT TIPO_USUARIO, NOME FROM MANGA.USUARIO WHERE ID = ?");
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado!']);
            exit;
        }
        
        $usuario = $resultado->fetch_assoc();
        $stmt->close();
        
        // Não permitir alterar administradores
        if ($usuario['TIPO_USUARIO'] == ADMINISTRADOR) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Não é possível alterar um administrador!']);
            exit;
        }
        
        // Verificar se já é autor
        if ($usuario['TIPO_USUARIO'] == AUTOR) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Este usuário já é um autor!']);
            exit;
        }
        
        // Promover a autor
        $stmt = $conexao->prepare("UPDATE MANGA.USUARIO SET TIPO_USUARIO = ? WHERE ID = ?");
        $tipoAutor = AUTOR;
        $stmt->bind_param("ii", $tipoAutor, $usuarioId);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => "✅ {$usuario['NOME']} foi promovido(a) a AUTOR com sucesso!\nAgora pode escrever e publicar artigos."
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao promover usuário: ' . $conexao->error]);
        }
        
        exit;
    }
    
    // ========== REMOVER USUÁRIO COMO AUTOR ==========
    else if ($acao === 'remover_autor') {
        
        $usuarioId = isset($_POST['usuario_id']) ? intval($_POST['usuario_id']) : 0;
        
        if ($usuarioId <= 0) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'ID de usuário inválido!']);
            exit;
        }
        
        // Verificar se o usuário existe e é autor
        $stmt = $conexao->prepare("SELECT TIPO_USUARIO, NOME FROM MANGA.USUARIO WHERE ID = ?");
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado!']);
            exit;
        }
        
        $usuario = $resultado->fetch_assoc();
        $stmt->close();
        
        // Não permitir alterar administradores
        if ($usuario['TIPO_USUARIO'] == ADMINISTRADOR) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Não é possível alterar um administrador!']);
            exit;
        }
        
        // Verificar se é autor
        if ($usuario['TIPO_USUARIO'] != AUTOR) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Este usuário não é um autor!']);
            exit;
        }
        
        // Remover como autor (tornar usuário comum)
        $stmt = $conexao->prepare("UPDATE MANGA.USUARIO SET TIPO_USUARIO = ? WHERE ID = ?");
        $tipoComum = USUARIO_COMUM;
        $stmt->bind_param("ii", $tipoComum, $usuarioId);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => "✅ {$usuario['NOME']} foi removido(a) como AUTOR.\nAgora é um usuário comum."
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao remover autor: ' . $conexao->error]);
        }
        
        exit;
    }
    
    // ========== EXCLUIR USUÁRIO ==========
    else if ($acao === 'excluir_usuario') {
        
        $usuarioId = isset($_POST['usuario_id']) ? intval($_POST['usuario_id']) : 0;
        
        if ($usuarioId <= 0) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'ID de usuário inválido!']);
            exit;
        }
        
        // Obter ID do admin logado
        $adminId = getUsuarioLogadoId();
        
        // Não permitir excluir a si mesmo
        if ($usuarioId == $adminId) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Você não pode excluir sua própria conta!']);
            exit;
        }
        
        // Verificar se o usuário existe
        $stmt = $conexao->prepare("SELECT TIPO_USUARIO, NOME FROM MANGA.USUARIO WHERE ID = ?");
        $stmt->bind_param("i", $usuarioId);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não encontrado!']);
            exit;
        }
        
        $usuario = $resultado->fetch_assoc();
        $stmt->close();
        
        // Não permitir excluir outros administradores
        if ($usuario['TIPO_USUARIO'] == ADMINISTRADOR) {
            http_response_code(403);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Não é possível excluir outros administradores!']);
            exit;
        }
        
        // Iniciar transação para garantir integridade dos dados
        $conexao->begin_transaction();
        
        try {
            // Excluir comentários do usuário
            $stmt = $conexao->prepare("DELETE FROM MANGA.COMENTARIO WHERE USUARIO_ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Excluir curtidas do usuário
            $stmt = $conexao->prepare("DELETE FROM MANGA.CURTIDA WHERE USUARIO_ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Excluir artigos do usuário (se for autor)
            $stmt = $conexao->prepare("DELETE FROM MANGA.ARTIGO WHERE AUTOR_ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Excluir entradas do herbário do usuário (se houver)
            $stmt = $conexao->prepare("DELETE FROM MANGA.HERBARIO WHERE USUARIO_ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Excluir histórico de consultas
            $stmt = $conexao->prepare("DELETE FROM MANGA.HISTORICO_CONSULTA WHERE USU_ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Por fim, excluir o usuário
            $stmt = $conexao->prepare("DELETE FROM MANGA.USUARIO WHERE ID = ?");
            $stmt->bind_param("i", $usuarioId);
            $stmt->execute();
            $stmt->close();
            
            // Confirmar transação
            $conexao->commit();
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => "✅ Usuário {$usuario['NOME']} foi excluído permanentemente com todos os seus dados."
            ]);
            
        } catch (Exception $e) {
            // Reverter transação em caso de erro
            $conexao->rollback();
            
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao excluir usuário: ' . $e->getMessage()]);
        }
        
        exit;
    }
    
    else {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Ação inválida!']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido']);
}

exit;
?>