<?php
// ========== PROCESSA INTERAÇÕES (CURTIDAS E COMENTÁRIOS) ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Receber dados da requisição
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Se não for JSON, tentar pegar do POST
if (!$data) {
    $data = $_POST;
}

// Suporte para GET, POST e JSON
$acao = $data['acao'] ?? $_POST['acao'] ?? $_GET['acao'] ?? '';
$artigo_id = isset($data['artigo_id']) ? intval($data['artigo_id']) : 
             (isset($_POST['artigo_id']) ? intval($_POST['artigo_id']) : 
             (isset($_GET['artigo_id']) ? intval($_GET['artigo_id']) : 0));

// Obter ID do usuário logado
$usuario_id = getUsuarioLogadoId();

// Ações que requerem autenticação
$acoes_protegidas = ['curtir', 'descurtir', 'comentar', 'deletar_comentario'];

if (in_array($acao, $acoes_protegidas) && !$usuario_id) {
    http_response_code(401);
    echo json_encode(['erro' => 'Usuário não autenticado', 'redirect' => 'login.html']);
    exit;
}

// Processar ação
switch($acao) {
    
    // ========== OBTER TOTAL DE CURTIDAS ==========
    case 'obter_curtidas':
        if ($artigo_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do artigo inválido']);
            exit;
        }
        
        // Contar total de curtidas
        $stmt = $conexao->prepare("SELECT COUNT(*) as total FROM MANGA.CURTIDA WHERE ARTIGO_ID = ?");
        $stmt->bind_param("i", $artigo_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $row = $resultado->fetch_assoc();
        $total = intval($row['total']);
        $stmt->close();
        
        // Verificar se o usuário logado já curtiu
        $ja_curtiu = false;
        if ($usuario_id) {
            $stmt = $conexao->prepare("SELECT ID FROM MANGA.CURTIDA WHERE ARTIGO_ID = ? AND USUARIO_ID = ?");
            $stmt->bind_param("ii", $artigo_id, $usuario_id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $ja_curtiu = ($resultado->num_rows > 0);
            $stmt->close();
        }
        
        echo json_encode([
            'total' => $total,
            'ja_curtiu' => $ja_curtiu
        ]);
        break;
    
    // ========== CURTIR ARTIGO ==========
    case 'curtir':
        if ($artigo_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do artigo inválido']);
            exit;
        }
        
        // Verificar se já curtiu
        $stmt = $conexao->prepare("SELECT ID FROM MANGA.CURTIDA WHERE ARTIGO_ID = ? AND USUARIO_ID = ?");
        $stmt->bind_param("ii", $artigo_id, $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows > 0) {
            $stmt->close();
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Você já curtiu este artigo']);
            exit;
        }
        $stmt->close();
        
        // Adicionar curtida
        $stmt = $conexao->prepare("INSERT INTO MANGA.CURTIDA (ARTIGO_ID, USUARIO_ID) VALUES (?, ?)");
        $stmt->bind_param("ii", $artigo_id, $usuario_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            // Obter novo total
            $stmt = $conexao->prepare("SELECT COUNT(*) as total FROM MANGA.CURTIDA WHERE ARTIGO_ID = ?");
            $stmt->bind_param("i", $artigo_id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $row = $resultado->fetch_assoc();
            $total = intval($row['total']);
            $stmt->close();
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Curtida adicionada!',
                'total' => $total
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['erro' => 'Erro ao adicionar curtida']);
        }
        break;
    
    // ========== DESCURTIR ARTIGO ==========
    case 'descurtir':
        if ($artigo_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do artigo inválido']);
            exit;
        }
        
        $stmt = $conexao->prepare("DELETE FROM MANGA.CURTIDA WHERE ARTIGO_ID = ? AND USUARIO_ID = ?");
        $stmt->bind_param("ii", $artigo_id, $usuario_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            // Obter novo total
            $stmt = $conexao->prepare("SELECT COUNT(*) as total FROM MANGA.CURTIDA WHERE ARTIGO_ID = ?");
            $stmt->bind_param("i", $artigo_id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $row = $resultado->fetch_assoc();
            $total = intval($row['total']);
            $stmt->close();
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Curtida removida!',
                'total' => $total
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['erro' => 'Erro ao remover curtida']);
        }
        break;
    
    // ========== OBTER COMENTÁRIOS ==========
    case 'obter_comentarios':
        if ($artigo_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do artigo inválido']);
            exit;
        }
        
        $stmt = $conexao->prepare(
            "SELECT C.ID, C.CONTEUDO, C.DATA_COMENTARIO, C.USUARIO_ID, U.NOME as AUTOR_NOME
             FROM MANGA.COMENTARIO C
             INNER JOIN MANGA.USUARIO U ON U.ID = C.USUARIO_ID
             WHERE C.ARTIGO_ID = ?
             ORDER BY C.DATA_COMENTARIO DESC"
        );
        $stmt->bind_param("i", $artigo_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $comentarios = [];
        while ($row = $resultado->fetch_assoc()) {
            $row['pode_deletar'] = ($usuario_id && $usuario_id == $row['USUARIO_ID']);
            $comentarios[] = $row;
        }
        
        $stmt->close();
        
        echo json_encode($comentarios);
        break;
    
    // ========== COMENTAR ==========
    case 'comentar':
        if ($artigo_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do artigo inválido']);
            exit;
        }
        
        $conteudo = isset($data['conteudo']) ? trim($data['conteudo']) : 
                    (isset($_POST['conteudo']) ? trim($_POST['conteudo']) : 
                    (isset($_POST['comentario']) ? trim($_POST['comentario']) : ''));
        
        if (empty($conteudo)) {
            http_response_code(400);
            echo json_encode(['erro' => 'Comentário não pode estar vazio']);
            exit;
        }
        
        // Inserir comentário
        $stmt = $conexao->prepare("INSERT INTO MANGA.COMENTARIO (ARTIGO_ID, USUARIO_ID, CONTEUDO) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $artigo_id, $usuario_id, $conteudo);
        
        if ($stmt->execute()) {
            $comentario_id = $stmt->insert_id;
            $stmt->close();
            
            // Buscar o comentário recém-criado
            $stmt = $conexao->prepare(
                "SELECT C.ID, C.CONTEUDO, C.DATA_COMENTARIO, C.USUARIO_ID, U.NOME as AUTOR_NOME
                 FROM MANGA.COMENTARIO C
                 INNER JOIN MANGA.USUARIO U ON U.ID = C.USUARIO_ID
                 WHERE C.ID = ?"
            );
            $stmt->bind_param("i", $comentario_id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $comentario = $resultado->fetch_assoc();
            $stmt->close();
            
            $comentario['pode_deletar'] = true;
            
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Comentário adicionado!',
                'comentario' => $comentario
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['erro' => 'Erro ao adicionar comentário']);
        }
        break;
    
    // ========== DELETAR COMENTÁRIO ==========
    case 'deletar_comentario':
        $comentario_id = isset($data['comentario_id']) ? intval($data['comentario_id']) : 
                        (isset($_POST['comentario_id']) ? intval($_POST['comentario_id']) : 0);
        
        if ($comentario_id <= 0) {
            http_response_code(400);
            echo json_encode(['erro' => 'ID do comentário inválido']);
            exit;
        }
        
        // Verificar se o comentário pertence ao usuário
        $stmt = $conexao->prepare("SELECT USUARIO_ID FROM MANGA.COMENTARIO WHERE ID = ?");
        $stmt->bind_param("i", $comentario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['erro' => 'Comentário não encontrado']);
            exit;
        }
        
        $comentario = $resultado->fetch_assoc();
        $stmt->close();
        
        if ($comentario['USUARIO_ID'] != $usuario_id) {
            http_response_code(403);
            echo json_encode(['erro' => 'Você não tem permissão para deletar este comentário']);
            exit;
        }
        
        // Deletar comentário
        $stmt = $conexao->prepare("DELETE FROM MANGA.COMENTARIO WHERE ID = ?");
        $stmt->bind_param("i", $comentario_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Comentário deletado com sucesso'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['erro' => 'Erro ao deletar comentário']);
        }
        break;
    
    default:
        http_response_code(400);
        echo json_encode(['erro' => 'Ação inválida']);
}

exit;
?>