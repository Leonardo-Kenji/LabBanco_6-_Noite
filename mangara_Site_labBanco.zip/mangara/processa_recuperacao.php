<?php
// ========== PROCESSA RECUPERAÇÃO DE SENHA ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verifica se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $acao = isset($_POST['acao']) ? $_POST['acao'] : '';
    
    // ========== ETAPA 1: SOLICITAR CÓDIGO ==========
    if ($acao === 'solicitar_codigo') {
        $email = isset($_POST['email']) ? trim($_POST['email']) : '';
        
        if (empty($email)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail é obrigatório!']);
            exit;
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail inválido!']);
            exit;
        }
        
        // Verificar se e-mail existe
        $stmt = $conexao->prepare("SELECT ID, NOME FROM MANGA.USUARIO WHERE EMAIL = ?");
        if (!$stmt) {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta']);
            exit;
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        if ($resultado->num_rows === 0) {
            $stmt->close();
            http_response_code(404);
            echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail não encontrado no sistema!']);
            exit;
        }
        
        $usuario = $resultado->fetch_assoc();
        $stmt->close();
        
        // Gerar código aleatório de 6 dígitos
        $codigo = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        
        // Armazenar código na sessão (em produção, seria no banco de dados)
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['recuperacao_email'] = $email;
        $_SESSION['recuperacao_codigo'] = $codigo;
        $_SESSION['recuperacao_tempo'] = time();
        $_SESSION['recuperacao_nome'] = $usuario['NOME'];
        
        // Em produção, você enviaria um e-mail aqui
        // mail($email, "Código de Recuperação de Senha", "Seu código é: $codigo");
        
        http_response_code(200);
        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Código enviado! (Demo: use 123456)',
            'nome_usuario' => $usuario['NOME']
        ]);
        exit;
    }
    
    // ========== ETAPA 2: VERIFICAR CÓDIGO ==========
    else if ($acao === 'verificar_codigo') {
        $codigo_fornecido = isset($_POST['codigo']) ? trim($_POST['codigo']) : '';
        
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        if (empty($codigo_fornecido)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Digite o código!']);
            exit;
        }
        
        if (!isset($_SESSION['recuperacao_codigo'])) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Nenhuma solicitação de recuperação ativa. Comece novamente.']);
            exit;
        }
        
        // Verificar se o código expirou (15 minutos)
        if (time() - $_SESSION['recuperacao_tempo'] > 900) {
            unset($_SESSION['recuperacao_codigo']);
            unset($_SESSION['recuperacao_email']);
            unset($_SESSION['recuperacao_tempo']);
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Código expirado! Comece novamente.']);
            exit;
        }
        
        // Verificar código (aceitar tanto o código real quanto 123456 para demo)
        if ($codigo_fornecido !== $_SESSION['recuperacao_codigo'] && $codigo_fornecido !== '123456') {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Código incorreto!']);
            exit;
        }
        
        // Código válido
        $_SESSION['recuperacao_verificado'] = true;
        
        http_response_code(200);
        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Código verificado com sucesso!'
        ]);
        exit;
    }
    
    // ========== ETAPA 3: ATUALIZAR SENHA ==========
    else if ($acao === 'atualizar_senha') {
        $nova_senha = isset($_POST['nova_senha']) ? $_POST['nova_senha'] : '';
        $confirma_senha = isset($_POST['confirma_senha']) ? $_POST['confirma_senha'] : '';
        
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        
        if (!isset($_SESSION['recuperacao_verificado']) || $_SESSION['recuperacao_verificado'] !== true) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Acesso negado. Verifique o código primeiro.']);
            exit;
        }
        
        if (empty($nova_senha) || empty($confirma_senha)) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Todos os campos são obrigatórios!']);
            exit;
        }
        
        if (strlen($nova_senha) < 6) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'A senha deve ter pelo menos 6 caracteres!']);
            exit;
        }
        
        if ($nova_senha !== $confirma_senha) {
            http_response_code(400);
            echo json_encode(['sucesso' => false, 'mensagem' => 'As senhas não conferem!']);
            exit;
        }
        
        $email = $_SESSION['recuperacao_email'];
        
        // Atualizar senha no banco de dados
        $stmt = $conexao->prepare("UPDATE MANGA.USUARIO SET SENHA = ? WHERE EMAIL = ?");
        if (!$stmt) {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta']);
            exit;
        }
        
        $stmt->bind_param("ss", $nova_senha, $email);
        
        if ($stmt->execute()) {
            $stmt->close();
            
            // Limpar variáveis de sessão
            unset($_SESSION['recuperacao_email']);
            unset($_SESSION['recuperacao_codigo']);
            unset($_SESSION['recuperacao_tempo']);
            unset($_SESSION['recuperacao_verificado']);
            unset($_SESSION['recuperacao_nome']);
            
            http_response_code(200);
            echo json_encode([
                'sucesso' => true,
                'mensagem' => 'Senha atualizada com sucesso! Você será redirecionado para o login.',
                'redirect' => 'login.html'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao atualizar a senha']);
        }
        
        exit;
    }
    
    else {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Ação inválida']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido']);
}

exit;
?>