<?php
// ========== PROCESSA CADASTRO ==========

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

// Verifica se é uma requisição POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Recebe os dados do formulário
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $data_nascimento = isset($_POST['data_nascimento']) ? $_POST['data_nascimento'] : '';
    $senha = isset($_POST['senha']) ? $_POST['senha'] : '';
    $confirma_senha = isset($_POST['confirma_senha']) ? $_POST['confirma_senha'] : '';
    
    // ========== VALIDAÇÕES ==========
    
    // Validar campos vazios
    if (empty($nome) || empty($email) || empty($data_nascimento) || empty($senha) || empty($confirma_senha)) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Todos os campos são obrigatórios!']);
        exit;
    }
    
    // Validar e-mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'E-mail inválido!']);
        exit;
    }
    
    // Validar comprimento da senha
    if (strlen($senha) < 6) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'A senha deve ter pelo menos 6 caracteres!']);
        exit;
    }
    
    // Validar se as senhas conferem
    if ($senha !== $confirma_senha) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'As senhas não conferem!']);
        exit;
    }
    
    // Validar data de nascimento
    if (strtotime($data_nascimento) > time()) {
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Data de nascimento inválida!']);
        exit;
    }
    
    // ========== VERIFICAR SE E-MAIL JÁ EXISTE ==========
    
    $stmt_verificar = $conexao->prepare("SELECT ID FROM MANGA.USUARIO WHERE EMAIL = ?");
    if (!$stmt_verificar) {
        http_response_code(500);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta: ' . $conexao->error]);
        exit;
    }
    
    $stmt_verificar->bind_param("s", $email);
    $stmt_verificar->execute();
    $resultado_verificar = $stmt_verificar->get_result();
    
    if ($resultado_verificar->num_rows > 0) {
        $stmt_verificar->close();
        http_response_code(400);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Este e-mail já está cadastrado!']);
        exit;
    }
    
    $stmt_verificar->close();
    
    // ========== INSERIR NOVO USUÁRIO ==========
    
    // CORREÇÃO: Tipo 3 = Usuário Comum (conforme a tabela na imagem)
    $tipo_usuario = 3;
    
    $stmt_inserir = $conexao->prepare(
        "INSERT INTO MANGA.USUARIO (TIPO_USUARIO, NOME, EMAIL, SENHA, DATANASCIMENTO) 
         VALUES (?, ?, ?, ?, ?)"
    );
    
    if (!$stmt_inserir) {
        http_response_code(500);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Erro na consulta: ' . $conexao->error]);
        exit;
    }
    
    $stmt_inserir->bind_param("issss", $tipo_usuario, $nome, $email, $senha, $data_nascimento);
    
    if ($stmt_inserir->execute()) {
        $stmt_inserir->close();
        
        http_response_code(201);
        echo json_encode([
            'sucesso' => true,
            'mensagem' => 'Conta criada com sucesso! Você será redirecionado para o login.',
            'redirect' => 'login.html'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['sucesso' => false, 'mensagem' => 'Erro ao criar a conta: ' . $conexao->error]);
    }
    
    exit;
    
} else {
    http_response_code(405);
    echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido']);
}

exit;
?>